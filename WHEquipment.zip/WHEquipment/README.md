# Lox Equipment Tracker

A VPS-ready warehouse equipment tracking app with SQLite persistence and real-time syncing across all connected users. Tracks trucks, stackers, scrubbers, dock plates, and sleds with a full edit history / audit trail.

## Requirements

- Node.js 20 or newer
- npm

## Quick Start

```bash
cp .env.example .env
npm install
npm start
```

Open:

```text
http://localhost:3040
```

## Development Mode

```bash
npm install
npm run dev
```

(Uses nodemon, configured via `nodemon.json` to watch only `server.js` and `public/`, ignoring the `data/` folder so DB writes don't trigger restarts.)

## VPS Deployment

### Option 1: Run directly with PM2

```bash
npm install -g pm2
cd equipment-tracker-app
cp .env.example .env
npm install --omit=dev
pm2 start server.js --name equipment-tracker
pm2 save
pm2 startup
```

### Option 2: Docker Compose

```bash
docker compose up -d --build
```

The app runs on port `3040` by default (set via `PORT` in `.env` or `docker-compose.yml`).

## Nginx Reverse Proxy Example

Replace `equipment.yourdomain.com` with your domain.

```nginx
server {
    server_name equipment.yourdomain.com;

    location / {
        proxy_pass http://127.0.0.1:3040;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

Then enable HTTPS with Certbot:

```bash
sudo certbot --nginx -d equipment.yourdomain.com
```

## Database

SQLite database path:

```text
data/equipment.db
```

The app uses WAL mode for better concurrent reads/writes and auto-seeds an initial equipment list the first time it runs (if the table is empty).

## API

### Health Check
```http
GET /api/health
```

### List Equipment
```http
GET /api/equipment
```

### Create Equipment
```http
POST /api/equipment
Content-Type: application/json

{
  "serial_number": "STJ-1001",
  "owner": "WLK 10",
  "brand": "Raymond",
  "model": "Truck",
  "status": "Working",
  "location": "Dock 4",
  "air_tagged": "Yes",
  "notes": "Ready for use"
}
```

### Update Equipment
```http
PUT /api/equipment/1
Content-Type: application/json
```

### Delete Equipment
```http
DELETE /api/equipment/1
```

### Get History for One Record
```http
GET /api/equipment/1/history
```

## Live Sync

The app uses Socket.io. Every create/update/delete broadcasts the refreshed equipment list to all connected clients, and every create/update broadcasts a refreshed history feed for that record.

## Production Notes

- Put the app behind Nginx with HTTPS.
- Keep regular backups of the `data/` folder.
- Use PM2 or Docker restart policies so the app restarts after reboot.
- For multiple VPS instances sharing state, migrate from SQLite to PostgreSQL.

## What Was Fixed

The original files you had were truncated mid-file (server.js cut off inside a SQL query builder, app.js cut off mid-function, index.html and styles.css likewise), which is exactly why Node threw `SyntaxError: Unexpected end of input` — the file physically ended before the code was complete. This package rebuilds:

- `server.js` — finishes `listHistory()`, adds the Express app, all CRUD routes (`GET/POST/PUT/DELETE /api/equipment`, `GET /api/equipment/:id/history`), and Socket.io wiring.
- `public/app.js` — finishes history rendering and adds the main `render()` function that builds equipment cards.
- `public/index.html` — closes out the history modal markup and adds script tags (Socket.io client, SheetJS for Excel export, app.js).
- `public/styles.css` — completes the history modal styling that was cut off mid-rule.
