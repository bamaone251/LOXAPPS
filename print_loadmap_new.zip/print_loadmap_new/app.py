import io
import os
from datetime import datetime
from flask import Flask, render_template, request, send_file, abort, url_for
from pypdf import PdfReader, PdfWriter
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter

app = Flask(__name__)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TEMPLATE_FILE = os.path.join(BASE_DIR, "LoadMap.pdf")
OUT_DIR = os.path.join(BASE_DIR, "data", "generated")
os.makedirs(OUT_DIR, exist_ok=True)

def build_pdf(date_str: str, total_runs: int, out_path: str):
    if not os.path.exists(TEMPLATE_FILE):
        raise FileNotFoundError(f"Missing template: {TEMPLATE_FILE}")

    reader = PdfReader(TEMPLATE_FILE)
    template_page = reader.pages[0]
    writer = PdfWriter()

    for run_num in range(1, total_runs + 1):
        packet = io.BytesIO()
        can = canvas.Canvas(packet, pagesize=letter)
        can.setFont("Helvetica-Bold", 13)
        can.drawString(165, 752, f" {run_num}")   # Run # (right after "Run:" label)
        can.drawString(60, 752, date_str)          # Date (further along the same top line)
        can.save()
        packet.seek(0)

        overlay_pdf = PdfReader(packet)
        overlay_page = overlay_pdf.pages[0]

        writer.add_page(template_page)
        writer.pages[-1].merge_page(overlay_page)

    with open(out_path, "wb") as f:
        writer.write(f)

def validate_date(mmddyy: str) -> str:
    datetime.strptime(mmddyy, "%m/%d/%y")
    return mmddyy

def recent_files(limit=2):
    files = []
    for name in os.listdir(OUT_DIR):
        path = os.path.join(OUT_DIR, name)
        if os.path.isfile(path) and name.lower().endswith(".pdf"):
            files.append({
                "name": name,
                "path": path,
                "mtime": os.path.getmtime(path)
            })
    files.sort(key=lambda x: x["mtime"], reverse=True)
    return files[:limit]

@app.route("/", methods=["GET"])
def home():
    files = recent_files(12)
    return render_template("index.html", files=files)

@app.route("/generate", methods=["POST"])
def generate():
    date_str = (request.form.get("date") or "").strip()
    runs_str = (request.form.get("runs") or "").strip()

    try:
        date_str = validate_date(date_str)
        total_runs = int(runs_str)
        if total_runs < 1 or total_runs > 300:
            abort(400, "Runs must be between 1 and 300.")
    except Exception as e:
        abort(400, f"Invalid input: {e}")

    filename = f"Load_Maps_{date_str.replace('/', '-')}_{int(datetime.now().timestamp())}.pdf"
    out_path = os.path.join(OUT_DIR, filename)

    try:
        build_pdf(date_str, total_runs, out_path)
    except Exception as e:
        abort(500, f"Failed to build PDF: {e}")

    return send_file(out_path, mimetype="application/pdf", as_attachment=True, download_name=filename)

@app.route("/download/<name>")
def download(name):
    safe = os.path.basename(name)
    path = os.path.join(OUT_DIR, safe)
    if not os.path.exists(path):
        abort(404)
    return send_file(path, mimetype="application/pdf", as_attachment=True, download_name=safe)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=3001, debug=False)
