# Print Load Map Generator

A Flask application that generates numbered load-map PDFs from the included PDF template.

## Run with Docker Compose

```bash
cp .env.example .env
docker compose up -d --build
```

Open:

```text
http://SERVER_IP:3001
```

Useful commands:

```bash
# View logs
docker compose logs -f

# Restart the app
docker compose restart

# Stop the app
docker compose down

# Rebuild after code changes
docker compose up -d --build
```

Generated PDFs are stored in the persistent Docker volume named `loadmap_generated`, so they remain available after the container is recreated.

### Change the host port

Edit `.env`:

```env
HOST_PORT=5055
```

Then recreate the container:

```bash
docker compose up -d
```

The app will then be available at `http://SERVER_IP:5055`.

## Run without Docker

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python app.py
```

Open `http://SERVER_IP:3001`.

## Production command without Docker

```bash
gunicorn --workers 2 --threads 2 --timeout 120 --bind 0.0.0.0:3001 app:app
```
