# Load Tools — PWA + Docker

Includes both calculators, the original icons, an install manifest, offline caching,
and an Nginx Docker container. No Node or Python server is needed on your VPS.
The existing formulas and device-local input saving are preserved.

## Start on your VPS

Requires Docker Engine with the Compose plugin installed. Extract the ZIP, then:

```bash
cd load-tools-pwa
cp .env.example .env
sudo docker compose up -d --build
sudo docker compose ps
curl -I http://127.0.0.1:5029/
```

The port defaults to 5029, bound to the VPS loopback interface for use with host
Nginx. You will not reach it by browsing to the public VPS IP on port 5029.
Change APP_PORT in .env if occupied, and change proxy_pass in the host Nginx
configuration to match. The container automatically restarts after a reboot
provided the Docker service starts at boot.

## Domain + HTTPS (Ubuntu/Debian with host Nginx)

1. Point your chosen domain's DNS A record to the VPS IPv4 address. If you add
   an AAAA record, make sure IPv6 is configured and reaches this VPS too.
2. Allow inbound ports 80 and 443 in your VPS firewall.
3. Replace loadtools.example.com in vps-nginx.conf.example with your domain.
   Copy it into /etc/nginx/sites-available/load-tools and enable it:

```bash
sudo cp vps-nginx.conf.example /etc/nginx/sites-available/load-tools
sudo ln -s /etc/nginx/sites-available/load-tools /etc/nginx/sites-enabled/load-tools
sudo nginx -t
sudo systemctl reload nginx
```

Do not create a second server block if this domain already has one. Update that
existing configuration instead. These instructions assume Nginx runs on the host;
a separate Nginx Docker container cannot use this host loopback upstream.

4. If Certbot and its Nginx plugin are not installed:

```bash
sudo apt update
sudo apt install certbot python3-certbot-nginx
```

5. Request HTTPS after DNS resolves correctly (use your actual domain):

```bash
sudo certbot --nginx -d loadtools.example.com --redirect
sudo certbot renew --dry-run
```

6. Visit https://YOUR-DOMAIN/ and reload once. Serve this app at the domain root.
   HTTPS is needed for service workers and installation on a remote server.

## Install and use offline

- Android Chrome / desktop Chrome or Edge: use the app's Install app button
  when available, or the browser menu's installation option.
- iPhone/iPad Safari: Share → Add to Home Screen.
- Desktop Firefox: use the website; native PWA installation support varies.
- First load needs internet. After the service worker installs, both calculators
  work offline. Inputs are saved separately on each device/browser, not on the VPS.
  Changing domain creates a separate storage area. Clearing site data removes inputs.

## Update / troubleshoot

```bash
sudo docker compose up -d --build
sudo docker compose logs --tail=100
```

After future changes to cached public files, change CACHE in public/sw.js to a new
load-tools-vN value. Reload, then close all app tabs/windows and reopen so the
new worker can activate. The initial release uses load-tools-v2.

If installation is unavailable, verify HTTPS has a trusted certificate and that
/manifest.webmanifest, /sw.js, and both icon URLs return 200. Existing installations
may show Open app rather than Install. To stop: sudo docker compose down.

If Docker reports exhausted address pools, inspect unused Docker networks with
sudo docker network ls and remove only networks you have confirmed are unused,
or adjust Docker's default address pools to non-overlapping ranges for your host.
Do not prune active application data or volumes.
