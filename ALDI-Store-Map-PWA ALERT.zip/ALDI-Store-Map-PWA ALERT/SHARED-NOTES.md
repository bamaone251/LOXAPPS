# Shared delivery notes — v5

All 231 locations now use shared delivery status and notes stored in SQLite on your VPS.
Other users see saved changes within about 5 seconds. Conflicting edits are rejected:
copy your draft, close and reopen the location, and review the latest note before saving.
Offline clients cannot save shared changes; displayed information may be stale.

## Upgrade your existing VPS installation

1. Back up delivery notes from each browser with existing notes before upgrading.
2. Copy the entire new package into your existing deployment directory, including
   server.py, Dockerfile.api, Caddyfile, .dockerignore, app/ and the Compose files.
3. Keep your .env and any necessary custom port/network settings. The supplied
   compose.yaml uses port 8677 and subnet 10.250.50.0/24. The new notes-api service,
   its persistent notes_data volume and store-map dependency are required.
4. In the SAME deployment directory (preserving your Compose project name), run:

```sh
docker compose -f compose.yaml up -d --build
docker compose -f compose.yaml logs --tail=100
```

5. Reload online, close all app tabs/windows, then reopen to activate the updated PWA.
6. In About these locations, click Import this browser's old notes on each browser
   that has notes to migrate. Or use Restore delivery notes with your old JSON backup.
   Import adds missing records but rejects the entire import if any existing shared
   record conflicts. No old browser notes are deleted. Review conflicting backups
   and enter the intended result through the location's shared editor.
7. Verify in a second browser that edits appear within 5 seconds.

For standalone HTTPS use compose.https.yaml instead, with your real DOMAIN in .env.
The notes API is internal to Docker and is reached through the map's existing port.
No extra public port is required. HTTPS is recommended for transport protection.

## Storage and access

Anyone who can reach this map can read and edit shared notes. There is no login.
Use your existing authenticated reverse proxy if this should be team-only.
Custom-added locations still remain browser-local; this update syncs delivery notes
and status by store code, not the custom-location list itself.

Shared notes survive container restarts and rebuilds in notes_data. Keep the same
Compose project name/directory so Compose reuses the same volume. Do not use
`docker compose down -v`: that removes persistent volumes. Download a shared notes
backup from About periodically. Restore accepts the same JSON format.

The Windows static launcher has no API and cannot save shared notes. Use Docker for
this version. No shared notes are cached by the service worker, so offline views
cannot be mistaken for a successful server save.
