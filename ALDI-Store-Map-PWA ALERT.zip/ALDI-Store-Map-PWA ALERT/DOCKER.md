See SHARED-NOTES.md for v5 deployment, migration, storage and access details.
