const CACHE = 'lox-aldi-pwa-v6.0-mapbox-' + self.registration.scope;
const ASSETS = ['./','index.html','style.css','app.js','data.js','visibility.js','pwa.js','locations.js','notes.js','radar.js','Tuglife.png','manifest.webmanifest','config.js','vendor/mapbox-gl.css','vendor/mapbox-gl.js','stores.csv','stores.geojson','icons/icon-192.png','icons/icon-512.png','icons/maskable-512.png','icons/apple-touch-icon.png'];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(ASSETS))));
self.addEventListener('activate',event=>event.waitUntil(self.clients.claim()));
self.addEventListener('fetch',event=>{
  if(event.request.method!=='GET') return;
  const url=new URL(event.request.url);
  if(url.pathname.includes('/api/'))return;
  if(url.origin!==self.location.origin || !url.href.startsWith(self.registration.scope)) return;
  event.respondWith(caches.open(CACHE).then(async cache=>{
    const saved=await cache.match(event.request,{ignoreSearch:true});
    if(saved) return saved;
    try{return await fetch(event.request)}catch(error){
      if(event.request.mode==='navigate')return cache.match('index.html');
      return Response.error();
    }
  }));
});
