const CUSTOM_KEY='lox-aldi-custom-locations-v1';
let customLocations=[];
const officialLocations=new Map(STORES.map(s=>[s.code.toUpperCase(),s]));
function validateLocation(s){
 if(!s||typeof s!=='object')throw Error('Invalid location record.');
 const clean={};
 for(const key of ['code','address','city','state','zip']){
  if(typeof s[key]!=='string'||!s[key].trim())throw Error('Code, address, city, state and ZIP are required.');
  clean[key]=s[key].trim();if(clean[key].length>180)throw Error('Location fields must be under 180 characters.');
 }
 clean.code=clean.code.toUpperCase();
 if(typeof s.lat!=='number'||!Number.isFinite(s.lat)||s.lat < -90||s.lat > 90||typeof s.lon!=='number'||!Number.isFinite(s.lon)||s.lon < -180||s.lon > 180)throw Error('Enter valid latitude (-90 to 90) and longitude (-180 to 180).');
 return {...clean,lat:s.lat,lon:s.lon,custom:true,geocode_source:'User supplied',precision:'User-selected coordinates',matched_address:[clean.address,clean.city,clean.state,clean.zip].join(', ')};
}
let storageProblem='';
try{
 const saved=JSON.parse(localStorage.getItem(CUSTOM_KEY)||'[]');
 if(!Array.isArray(saved))throw Error('Invalid saved data.');
 const codes=new Set();
 customLocations=saved.map(validateLocation);
 for(const s of customLocations){if(codes.has(s.code))throw Error('Duplicate saved code.');codes.add(s.code);}
 // Preserve saved custom entries when a data update adds the same official code.
 for(const s of customLocations){const i=STORES.findIndex(base=>base.code.toUpperCase()===s.code);if(i>=0)STORES.splice(i,1);}
 STORES.push(...customLocations);
}catch(e){storageProblem='Saved locations could not be loaded. Nothing was overwritten. Restore a backup or check browser storage.';customLocations=[];}
window.addEventListener('DOMContentLoaded',()=>{
 const dialog=$('location-dialog'),form=$('location-form'),message=$('location-message');let editing=null,picking=false;
 const fields=['code','address','city','state','zip','lat','lon'];
 const allBaseStates=Array.from($('state').options).map(o=>o.value).filter(Boolean);
 function states(){const selected=$('state').value;const names=[...new Set([...allBaseStates,...STORES.map(s=>s.state)])].sort();$('state').innerHTML='<option value="">All states</option>'+names.map(s=>`<option>${esc(s)}</option>`).join('');$('state').value=names.includes(selected)?selected:'';}
 function persist(next){if(storageProblem)throw Error(storageProblem);localStorage.setItem(CUSTOM_KEY,JSON.stringify(next));customLocations=next;}
 function restoreOfficial(code){const original=officialLocations.get(code);if(original&&!STORES.some(s=>s.code.toUpperCase()===code)){STORES.push(original);addMarker(original);}}
 function refresh(){states();$('search').value='';$('state').value='';render();}
 function openLocation(s){editing=s?.code||null;form.reset();message.textContent='';$('location-title').textContent=s?'Edit location':'Add location';$('delete-location').hidden=!s;for(const k of fields)$('loc-'+k).value=s?.[k]??'';dialog.showModal();}
 $('add-location').addEventListener('click',()=>openLocation());
 $('cancel-location').addEventListener('click',()=>dialog.close());
 $('pick-location').addEventListener('click',()=>{picking=true;dialog.close();$('pick-banner').hidden=false;setPickMode(true);});
 $('cancel-pick').addEventListener('click',()=>{picking=false;$('pick-banner').hidden=true;setPickMode(false);dialog.showModal();});
 map.on('click',e=>{if(!picking)return;picking=false;$('loc-lat').value=e.lngLat.lat.toFixed(6);$('loc-lon').value=e.lngLat.lng.toFixed(6);$('pick-banner').hidden=true;setPickMode(false);dialog.showModal();});
 form.addEventListener('submit',e=>{e.preventDefault();try{
  const raw=Object.fromEntries(fields.map(k=>[k,$('loc-'+k).value]));
  if(!raw.lat.trim()||!raw.lon.trim())throw Error('Enter coordinates or choose a point on the map.');
  raw.lat=Number(raw.lat);raw.lon=Number(raw.lon);const s=validateLocation(raw);
  if(STORES.some(x=>x.code.toUpperCase()===s.code&&x.code!==editing))throw Error('That store code already exists. Use a unique code.');
  const next=customLocations.filter(x=>x.code!==editing);next.push(s);persist(next);
  if(editing){const idx=STORES.findIndex(x=>x.code===editing);STORES.splice(idx,1);markers.get(editing).remove();markers.delete(editing);}
  STORES.push(s);addMarker(s);if(editing&&editing!==s.code)restoreOfficial(editing);refresh();dialog.close();zoomToStore(s.code);
 }catch(error){message.textContent=error.message;}});
 $('delete-location').addEventListener('click',()=>{if(!editing||!confirm('Delete this custom location from this browser?'))return;try{persist(customLocations.filter(s=>s.code!==editing));const idx=STORES.findIndex(s=>s.code===editing);STORES.splice(idx,1);markers.get(editing).remove();markers.delete(editing);restoreOfficial(editing);refresh();dialog.close();}catch(e){message.textContent=e.message;}});
 map.on('popupopen',event=>{const button=event.popup.getElement().querySelector('[data-edit-location]');if(button)button.onclick=()=>openLocation(customLocations.find(s=>s.code===button.dataset.editLocation));});
 function download(name,text,type){const url=URL.createObjectURL(new Blob([text],{type}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
 document.querySelector('a.export')?.addEventListener('click',e=>{e.preventDefault();download('stores.geojson',JSON.stringify({type:'FeatureCollection',features:visibleStores().map(s=>({type:'Feature',properties:{...s,...deliveryInfo(s.code)},geometry:{type:'Point',coordinates:[s.lon,s.lat]}}))},null,2),'application/geo+json');});
 document.querySelector('a[href="stores.csv"]').addEventListener('click',e=>{e.preventDefault();const keys=['code','address','city','state','zip','lat','lon','geocode_source','precision','blocked','notes'];const quote=v=>'"'+String(v??'').replace(/"/g,'""')+'"';download('stores.csv','\ufeff'+[keys.join(','),...visibleStores().map(s=>keys.map(k=>quote(({...s,...deliveryInfo(s.code)})[k])).join(','))].join('\r\n'),'text/csv');});
 $('backup-locations').addEventListener('click',()=>download('custom-locations-backup.json',JSON.stringify({version:1,locations:customLocations},null,2),'application/json'));
 $('restore-locations').addEventListener('click',()=>$('backup-file').click());
 $('backup-file').addEventListener('change',async e=>{const file=e.target.files[0];if(!file)return;try{
  if(file.size>5000000)throw Error('Backup exceeds 5 MB.');const data=JSON.parse(await file.text());if(data.version!==1||!Array.isArray(data.locations))throw Error('Choose a custom locations backup JSON file.');
  const incoming=data.locations.map(validateLocation),codes=new Set(STORES.map(s=>s.code.toUpperCase())),added=[];
  for(const s of incoming){if(codes.has(s.code)){const existing=[...STORES,...added].find(x=>x.code.toUpperCase()===s.code);if(!existing||['address','city','state','zip','lat','lon'].some(k=>existing[k]!==s[k]))throw Error('Conflicting store code '+s.code+'. No locations were imported.');continue;}codes.add(s.code);added.push(s);}
  persist([...customLocations,...added]);STORES.push(...added);added.forEach(addMarker);refresh();$('custom-status').textContent=`Imported ${added.length} locations. Saved in this browser.`;
 }catch(error){$('custom-status').textContent=error.message;}finally{e.target.value='';}});
 states();if(storageProblem)$('custom-status').textContent=storageProblem;
});
