/* ==========================================================================
   MAPBOX SETTINGS
   --------------------------------------------------------------------------
   Public token (starts with "pk."). It is meant to be used in the browser,
   but lock it to your site so nobody else can use it:
   Mapbox account → Tokens → this token → URL restrictions → add your domain
   (and http://localhost if you test locally).
   ========================================================================== */

const MAPBOX_TOKEN = 'pk.eyJ1IjoiYmFtYW9uZTI1MSIsImEiOiJjbWFjYW41dG0wMWF4MnFvOWs1dGlhMmk4In0.F0cBgDBviYkoJLLubYOr2A';
