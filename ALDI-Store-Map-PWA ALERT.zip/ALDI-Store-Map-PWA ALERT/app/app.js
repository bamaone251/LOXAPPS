/* ==========================================================================
   STORE MAP — MAIN MAP (Mapbox GL JS)
   --------------------------------------------------------------------------
   1. Helpers & settings
   2. Map + basemaps (Street / Dark / Satellite)
   3. 3D view (tilt + rotate)
   4. Store markers (pin + code label + popup)
   5. Store list, search & filters
   6. Toolbar wiring

   Used by other files:
     map               the Mapbox map       (locations.js, notes.js, radar.js)
     markers           code → StoreMarker   (locations.js, notes.js)
     addMarker(s)      create a store pin   (locations.js)
     storeIcon(s)      pin HTML for a store (notes.js)
     zoomToStore(c)    fly to + open popup  (locations.js)
     render()          redraw list + pins   (locations.js)
     map 'popupopen'   fired when a store popup opens (locations.js, notes.js)
   ========================================================================== */


/* ---------- 1. Helpers & settings ---------- */

const colors = { Alabama: '#007fac', Mississippi: '#9254c8', Louisiana: '#de8221', Florida: '#1b966d', Georgia: '#c84d67' };
const abbr = { Alabama: 'AL', Mississippi: 'MS', Louisiana: 'LA', Florida: 'FL', Georgia: 'GA' };

const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const START_VIEW = { center: [-88, 32], zoom: 5 };
const STORE_ZOOM = 14;              // zoom when you pick a store from the list
const FIT_MAX_ZOOM = 13;            // "Fit results" never zooms in closer than this
const VIEW_3D = { pitch: 60, bearing: -20 };


/* ---------- 2. Map + basemaps ---------- */

// All three use Mapbox Standard, which has 3D buildings built in.
// Street and Dark are the same style with a different light setting,
// so switching between them is instant.
const BASEMAPS = {
  street:    { style: 'mapbox://styles/mapbox/standard',           lightPreset: 'day' },
  dark:      { style: 'mapbox://styles/mapbox/standard',           lightPreset: 'night' },
  satellite: { style: 'mapbox://styles/mapbox/standard-satellite', lightPreset: 'day' }
};

let currentBasemap = 'street';

mapboxgl.accessToken = MAPBOX_TOKEN;

const map = new mapboxgl.Map({
  container: 'map',
  style: BASEMAPS.street.style,
  center: START_VIEW.center,
  zoom: START_VIEW.zoom,
  maxPitch: 75
});

// Zoom buttons + compass. Drag the compass to tilt/rotate, click it to reset north.
map.addControl(new mapboxgl.NavigationControl({ visualizePitch: true }), 'bottom-right');
map.addControl(new mapboxgl.ScaleControl({ unit: 'imperial' }), 'bottom-right');

// Runs every time a style finishes loading (first load + Satellite switches)
map.on('style.load', applyBasemapSettings);

function applyBasemapSettings() {
  const basemap = BASEMAPS[currentBasemap];
  map.setConfigProperty('basemap', 'lightPreset', basemap.lightPreset);
  // Hide shops/restaurants etc. so store pins stand out
  map.setConfigProperty('basemap', 'showPointOfInterestLabels', false);
}

function setBasemap(name) {
  const next = BASEMAPS[name];
  const sameStyle = next.style === BASEMAPS[currentBasemap].style;
  currentBasemap = name;

  if (sameStyle) applyBasemapSettings();
  // diff:false forces a full reload so 'style.load' fires and re-adds the radar
  else map.setStyle(next.style, { diff: false });
}

// Bad token, blocked domain, offline, etc.
let mapErrorShown = false;
map.on('error', (e) => {
  const status = e && e.error && e.error.status;
  if (mapErrorShown || !(status === 401 || status === 403)) return;
  mapErrorShown = true;
  $('error').textContent = 'The map background could not load. Check the Mapbox token in config.js and its URL restrictions.';
  $('error').hidden = false;
});


/* ---------- 3. 3D view (tilt + rotate) ---------- */
// Mouse:  right-click drag (or Ctrl + drag) to tilt and rotate
// Touch:  two-finger drag up/down to tilt, two-finger twist to rotate

function is3D() {
  return map.getPitch() > 5;
}

function toggle3D() {
  const goingTo3D = !is3D();
  map.easeTo({
    pitch: goingTo3D ? VIEW_3D.pitch : 0,
    bearing: goingTo3D ? VIEW_3D.bearing : 0,
    zoom: goingTo3D ? Math.max(map.getZoom(), 6) : map.getZoom(),
    duration: 1000
  });
}

function update3DButton() {
  $('view3d').setAttribute('aria-pressed', String(is3D()));
}

map.on('pitchend', update3DButton);


/* ---------- 4. Store markers ---------- */

const markers = new Map();          // code → StoreMarker
let activePopup = null;
let filtered = STORES;

class StoreMarker {
  constructor(store) {
    this.store = store;
    this.onMap = false;

    this.el = document.createElement('div');
    this.el.className = 'store-marker';
    this.el.title = `${store.code} — ${store.city}`;

    this.label = document.createElement('div');
    this.label.className = 'code-label';

    this.pin = document.createElement('div');
    this.pin.className = 'store-pin';

    this.el.append(this.label, this.pin);
    this.el.addEventListener('click', (e) => {
      e.stopPropagation();          // don't let the map treat this as a map click
      this.openPopup();
      selectRow(store.code);
    });

    this.marker = new mapboxgl.Marker({ element: this.el, anchor: 'center' })
      .setLngLat([store.lon, store.lat]);
  }

  setIcon(html) { this.pin.innerHTML = html; }
  setTooltipContent(html) { this.label.innerHTML = html; }   // caller escapes
  getLngLat() { return this.marker.getLngLat(); }

  show() {
    if (this.onMap) return;
    this.marker.addTo(map);
    this.onMap = true;
  }

  remove() {
    if (activePopup && activePopup.storeCode === this.store.code) activePopup.remove();
    this.marker.remove();
    this.onMap = false;
  }

  openPopup() {
    if (activePopup) activePopup.remove();
    activePopup = new mapboxgl.Popup({ offset: 16, maxWidth: '320px', focusAfterOpen: false })
      .setLngLat(this.getLngLat())
      .setHTML(popupHtml(this.store))
      .addTo(map);
    activePopup.storeCode = this.store.code;
    map.fire('popupopen', { popup: activePopup });
  }
}

function addMarker(s) {
  markers.set(s.code, new StoreMarker(s));
}

// Pin HTML: red "!" if the store can't take a truck, blue "N" if it has notes,
// otherwise a dot in the state's color.
function storeIcon(s) {
  const n = deliveryInfo(s.code);
  if (n.blocked) return '<div class="delivery-pin blocked-pin" aria-label="Unable to receive truck">!</div>';
  if (n.notes) return '<div class="delivery-pin notes-pin" aria-label="Notes saved">N</div>';
  return `<div class="pin" style="--color:${colors[s.state] || '#526e7c'}"></div>`;
}

function labelHtml(s) {
  const n = deliveryInfo(s.code);
  return esc(s.code) + (n.blocked ? ' · UNABLE TO RECEIVE TRUCK' : n.notes ? ' · Notes' : '');
}

function popupHtml(s) {
  const st = esc(abbr[s.state] || s.state);
  const full = `${s.address}, ${s.city}, ${abbr[s.state] || s.state} ${s.zip}`;
  const directions = `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(full)}`;
  const editButton = s.custom
    ? `<p><button class="edit-location" data-edit-location="${esc(s.code)}">Edit location</button></p>`
    : '';

  return `
    <h2>${esc(s.code)} · ${esc(s.city)}</h2>
    <p>${esc(s.address)}<br>${esc(s.city)}, ${st} ${esc(s.zip)}</p>
    <a class="direction" href="${directions}" target="_blank" rel="noopener">Get directions ↗</a>
    ${editButton}
    ${deliveryPopup(s.code)}
    <div class="meta">
      <p>${s.lat.toFixed(6)}, ${s.lon.toFixed(6)}<br>WGS 84 / EPSG:4326</p>
      <p>${esc(s.geocode_source)} · ${esc(s.precision)}<br>Matched: ${esc(s.matched_address)}</p>
    </div>`;
}

// Add location → "Choose point on map": close popups, make pins click-through
function setPickMode(on) {
  if (on && activePopup) activePopup.remove();
  map.getContainer().classList.toggle('picking', on);
  map.getCanvas().style.cursor = on ? 'crosshair' : '';
}

function zoomToStore(code) {
  const m = markers.get(code);
  if (!m) return;
  map.flyTo({ center: m.getLngLat(), zoom: STORE_ZOOM, duration: 1200 });
  m.openPopup();
  selectRow(code);
}

STORES.forEach(addMarker);


/* ---------- 5. Store list, search & filters ---------- */

function selectRow(code) {
  const rows = document.querySelectorAll('.store');
  rows.forEach((row) => row.classList.toggle('selected', row.dataset.code === code));
  const row = Array.from(rows).find((r) => r.dataset.code === code);
  if (row) row.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
}

function fit(animate = true) {
  if (!filtered.length) return;
  const bounds = new mapboxgl.LngLatBounds();
  filtered.forEach((s) => bounds.extend([s.lon, s.lat]));
  map.fitBounds(bounds, {
    padding: { top: 70, bottom: 50, left: 40, right: 40 },
    maxZoom: FIT_MAX_ZOOM,
    pitch: map.getPitch(),
    bearing: map.getBearing(),
    duration: animate ? 800 : 0
  });
}

function storeRowHtml(s) {
  return `
    <button class="store" data-code="${esc(s.code)}">
      <span class="top">
        <span class="code" style="--color:${colors[s.state] || '#526e7c'}">${esc(s.code)}</span>
        <span class="city">${esc(s.city)}, ${esc(abbr[s.state] || s.state)}</span>
      </span>
      <span class="address">${esc(s.address)}<br>${esc(s.zip)}</span>
      ${deliveryBadge(s.code)}
    </button>`;
}

function render(animate = true) {
  const visible = visibleStores();
  const query = $('search').value.trim().toLowerCase();
  const state = $('state').value;

  filtered = visible.filter((s) =>
    (!state || s.state === state) &&
    [s.code, s.city, s.address, s.zip, s.state].join(' ').toLowerCase().includes(query)
  );

  // Pins: show matches, hide everything else
  const show = new Set(filtered.map((s) => s.code));
  for (const [code, m] of markers) {
    if (show.has(code)) {
      m.setIcon(storeIcon(m.store));
      m.setTooltipContent(labelHtml(m.store));
      m.show();
    } else if (m.onMap) {
      m.remove();
    }
  }

  // Counts
  document.querySelector('.legend span:last-child').textContent = `${visible.length} mapped locations`;
  $('count').textContent = `${filtered.length} of ${visible.length} stores`;

  // Sidebar list
  $('list').innerHTML = filtered.map(storeRowHtml).join('') ||
    '<p class="empty">No matching stores. Try another city, code or address.</p>';
  document.querySelectorAll('.store').forEach((row) =>
    row.addEventListener('click', () => zoomToStore(row.dataset.code))
  );

  updateLabels();
  fit(animate);
}

function updateLabels() {
  map.getContainer().classList.toggle('hide-store-labels', !$('labels').checked);
}


/* ---------- 6. Toolbar wiring ---------- */

$('search').addEventListener('input', () => render());
$('state').addEventListener('change', () => render());
$('fit').addEventListener('click', () => fit());
$('reset').addEventListener('click', () => {
  $('search').value = '';
  $('state').value = '';
  render();
});
$('labels').addEventListener('change', updateLabels);
$('basemap').addEventListener('change', () => setBasemap($('basemap').value));
$('view3d').addEventListener('click', toggle3D);

render(false);
