/* ==========================================================================
   WEATHER RADAR LAYER (Mapbox GL)
   --------------------------------------------------------------------------
   NEXRAD base reflectivity from the Iowa Environmental Mesonet (IEM).
   Free, no API key, US coverage, new frame every 5 minutes.

   - "Radar" checkbox   turns the layer on/off (remembered per browser)
   - "Loop" button      animates the last 50 minutes
   - Time label         shows the time of the frame on screen
   - Tiles refresh automatically every 5 minutes while radar is on

   Needs: the global `map` from app.js, so load this AFTER app.js.
   ========================================================================== */

(function () {
  'use strict';

  /* ---------- Settings (safe to tweak) ---------- */

  const TILE_BASE = 'https://mesonet.agron.iastate.edu/cache/tile.py/1.0.0/nexrad-n0q-900913';
  const OPACITY = 0.6;                    // 0 = invisible, 1 = solid
  const FRAME_MS = 500;                   // time each loop frame is shown
  const LOOP_PAUSE_MS = 1500;             // extra pause on the newest frame
  const REFRESH_MS = 5 * 60 * 1000;       // fetch fresh tiles every 5 minutes
  const MAX_NATIVE_ZOOM = 10;             // radar detail limit; scaled up beyond this
  const STORAGE_KEY = 'lox-radar-on';

  // Minutes ago for each loop frame, oldest first. 0 = latest.
  const FRAME_OFFSETS = [50, 45, 40, 35, 30, 25, 20, 15, 10, 5, 0];
  const LATEST = FRAME_OFFSETS.length - 1;

  const ATTRIBUTION = 'Radar &copy; <a href="https://mesonet.agron.iastate.edu/" target="_blank" rel="noopener">Iowa Environmental Mesonet</a>';

  /* ---------- Elements ---------- */

  const ui = {
    toggle: document.getElementById('radar'),
    play: document.getElementById('radar-play'),
    time: document.getElementById('radar-time')
  };

  if (typeof map === 'undefined' || !ui.toggle) return;

  /* ---------- State ---------- */

  let radarOnState = false;
  let looping = false;
  let current = LATEST;
  let playTimer = null;
  let refreshTimer = null;

  /* ---------- Map layers ---------- */
  // One raster layer per frame. Only the newest is loaded unless the loop runs.

  const layerId = (i) => 'radar-' + FRAME_OFFSETS[i];

  function tileUrl(minutes) {
    const suffix = minutes === 0 ? '' : '-m' + String(minutes).padStart(2, '0') + 'm';
    // Cache key changes every 5 min so the browser grabs new tiles
    const cacheKey = Math.floor(Date.now() / REFRESH_MS);
    return TILE_BASE + suffix + '/{z}/{x}/{y}.png?v=' + cacheKey;
  }

  function addFrame(i) {
    const id = layerId(i);
    if (map.getLayer(id)) return;
    if (!map.getSource(id)) {
      map.addSource(id, {
        type: 'raster',
        tiles: [tileUrl(FRAME_OFFSETS[i])],
        tileSize: 256,
        maxzoom: MAX_NATIVE_ZOOM,
        attribution: ATTRIBUTION
      });
    }
    map.addLayer({
      id,
      type: 'raster',
      source: id,
      slot: 'middle',               // above roads/land, below labels & 3D buildings
      paint: {
        'raster-opacity': 0,
        'raster-opacity-transition': { duration: 0 },
        'raster-fade-duration': 0
      }
    });
  }

  function removeFrame(i) {
    const id = layerId(i);
    if (map.getLayer(id)) map.removeLayer(id);
    if (map.getSource(id)) map.removeSource(id);
  }

  // Make the map match the current state. Safe to call any time;
  // if the style is still loading, 'style.load' calls it again.
  function syncLayers() {
    try {
      FRAME_OFFSETS.forEach((_, i) => {
        const wanted = radarOnState && (looping || i === LATEST);
        wanted ? addFrame(i) : removeFrame(i);
      });
      showFrame(current);
    } catch (e) {
      /* style not ready yet — handled by 'style.load' */
    }
  }

  function showFrame(i) {
    current = i;
    FRAME_OFFSETS.forEach((_, j) => {
      const id = layerId(j);
      if (map.getLayer(id)) map.setPaintProperty(id, 'raster-opacity', j === i ? OPACITY : 0);
    });
    updateTimeLabel();
  }

  function refreshTiles() {
    FRAME_OFFSETS.forEach((minutes, i) => {
      const source = map.getSource(layerId(i));
      if (source && source.setTiles) source.setTiles([tileUrl(minutes)]);
    });
    updateTimeLabel();
  }

  // Switching to/from Satellite loads a new style, which drops custom layers
  map.on('style.load', syncLayers);

  /* ---------- On / off ---------- */

  function radarOn() {
    radarOnState = true;
    current = LATEST;
    syncLayers();
    ui.play.hidden = false;
    ui.time.hidden = false;
    clearInterval(refreshTimer);
    refreshTimer = setInterval(refreshTiles, REFRESH_MS);
  }

  function radarOff() {
    stopLoop();
    radarOnState = false;
    clearInterval(refreshTimer);
    refreshTimer = null;
    syncLayers();
    ui.play.hidden = true;
    ui.time.hidden = true;
  }

  /* ---------- Loop animation ---------- */

  function startLoop() {
    looping = true;
    syncLayers();                   // loads every frame (hidden) for a smooth loop
    ui.play.textContent = '❚❚ Stop';
    ui.play.setAttribute('aria-pressed', 'true');
    tick(0);
  }

  function tick(i) {
    showFrame(i);
    const isLast = i === LATEST;
    playTimer = setTimeout(() => tick(isLast ? 0 : i + 1), isLast ? FRAME_MS + LOOP_PAUSE_MS : FRAME_MS);
  }

  function stopLoop() {
    if (!looping) return;
    clearTimeout(playTimer);
    playTimer = null;
    looping = false;
    current = LATEST;
    syncLayers();                   // back to newest frame, unload the rest
    ui.play.textContent = '▶ Loop';
    ui.play.setAttribute('aria-pressed', 'false');
  }

  /* ---------- Time label ---------- */

  function updateTimeLabel() {
    const minutes = FRAME_OFFSETS[current];
    const frameTime = new Date(Date.now() - minutes * 60 * 1000);
    const clock = frameTime.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
    ui.time.textContent = minutes === 0 ? 'Live · ' + clock : '−' + minutes + 'm · ' + clock;
  }

  /* ---------- Remember on/off ---------- */

  function saveSetting(on) {
    try { localStorage.setItem(STORAGE_KEY, on ? '1' : '0'); } catch (e) { /* storage blocked */ }
  }

  function loadSetting() {
    try { return localStorage.getItem(STORAGE_KEY) === '1'; } catch (e) { return false; }
  }

  /* ---------- Wire up ---------- */

  ui.toggle.addEventListener('change', () => {
    ui.toggle.checked ? radarOn() : radarOff();
    saveSetting(ui.toggle.checked);
  });

  ui.play.addEventListener('click', () => {
    looping ? stopLoop() : startLoop();
  });

  // Don't animate (and burn data) in a background tab
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) stopLoop();
  });

  if (loadSetting()) {
    ui.toggle.checked = true;
    radarOn();
  }
})();
