const NOTES_KEY='lox-aldi-delivery-notes-v1';
let deliveryNotes={},notesError='';
function validateNotes(value){
 if(!value||typeof value!=='object'||Array.isArray(value))throw Error('Invalid notes backup.');
 const result=Object.create(null);
 for(const [code,n] of Object.entries(value)){
  if(!code||code.length>180||!n||typeof n.blocked!=='boolean'||typeof n.notes!=='string'||n.notes.length>5000)throw Error('Invalid delivery note.');
  result[code]={blocked:n.blocked,notes:n.notes};
 }return result;
}
let sharedReady=false;
function deliveryInfo(code){return Object.hasOwn(deliveryNotes,code)?deliveryNotes[code]:{blocked:false,notes:''};}
function deliveryBadge(code){const n=deliveryInfo(code);return (n.blocked?'<strong class="delivery-blocked">UNABLE TO RECEIVE TRUCK</strong>':'')+(n.notes?`<span class="delivery-has-notes">Notes: ${esc(n.notes)}</span>`:'');}
function deliveryPopup(code){const n=deliveryInfo(code);return `<form class="delivery-form" data-delivery-code="${esc(code)}"><label><input type="checkbox" name="blocked" ${n.blocked?'checked':''}> UNABLE TO RECEIVE TRUCK</label><label>Location notes<textarea name="notes" rows="4" maxlength="5000" placeholder="Delivery restrictions, entrance instructions, contacts…">${esc(n.notes)}</textarea></label><button type="submit">Save status &amp; notes</button><p class="delivery-message" role="status"></p><small>${sharedReady?'Shared with everyone using this map.':'Not connected. Status may be out of date.'}</small></form>`;}

async function notesRequest(path,body){
 const response=await fetch('./api/'+path,{method:body===undefined?'GET':'POST',headers:{'Content-Type':'application/json'},body:body===undefined?undefined:JSON.stringify(body),cache:'no-store',signal:AbortSignal.timeout(12000)});
 const data=await response.json();if(!response.ok)throw Error(data.error||'Unable to sync.');return data;
}
function paintDelivery(){
 for(const s of STORES){const marker=markers.get(s.code);marker.setIcon(storeIcon(s));marker.setTooltipContent(esc(s.code)+(deliveryInfo(s.code).blocked?' · UNABLE TO RECEIVE TRUCK':deliveryInfo(s.code).notes?' · Notes':''));}
 document.querySelectorAll('.store').forEach(row=>{row.querySelectorAll('.delivery-blocked,.delivery-has-notes').forEach(el=>el.remove());row.insertAdjacentHTML('beforeend',deliveryBadge(row.dataset.code));});
 const form=document.querySelector('.delivery-form');
 if(form&&!form.dataset.dirty){const n=deliveryInfo(form.dataset.deliveryCode);form.elements.blocked.checked=n.blocked;form.elements.notes.value=n.notes;form.dataset.revision=n.revision||0;}
}
let syncBusy=false;
async function syncNotes(){
 if(syncBusy)return false;syncBusy=true;
 try{const data=await notesRequest('notes');validateNotes(data);deliveryNotes=data;sharedReady=true;paintDelivery();$('notes-status').textContent='Shared notes connected. Updates refresh every 5 seconds.';return true;}
 catch(e){sharedReady=false;$('notes-status').textContent='Shared notes unavailable. Displayed information may be out of date. Reconnect before saving.';return false;}
 finally{syncBusy=false;}
}
window.addEventListener('DOMContentLoaded',()=>{
 map.on('popupopen',e=>{
  const form=e.popup.getElement().querySelector('.delivery-form');if(!form)return;
  form.dataset.revision=deliveryInfo(form.dataset.deliveryCode).revision||0;
  form.addEventListener('input',()=>{form.dataset.dirty='1';});
  form.addEventListener('submit',async event=>{event.preventDefault();const message=form.querySelector('.delivery-message'),button=form.querySelector('button');button.disabled=true;
   try{if(!sharedReady)throw Error('Not connected to shared notes. Wait for the connection and try again.');
    await notesRequest('notes/'+encodeURIComponent(form.dataset.deliveryCode),{blocked:form.elements.blocked.checked,notes:form.elements.notes.value.trim(),revision:Number(form.dataset.revision)});
    delete form.dataset.dirty;await syncNotes();message.textContent='Saved to server for all users.';
   }catch(err){message.textContent=err.message;await syncNotes();}finally{button.disabled=false;}
  });
 });
 $('backup-notes').onclick=()=>{if(!sharedReady){$('notes-status').textContent='Reconnect before backing up shared notes.';return;}const url=URL.createObjectURL(new Blob([JSON.stringify({version:1,deliveryNotes},null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download='shared-delivery-notes-backup.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);};
 async function importNotes(data){validateNotes(data);await notesRequest('import',data);await syncNotes();$('notes-status').textContent='Notes imported for all users.';}
 $('import-local-notes').onclick=async()=>{try{await importNotes(JSON.parse(localStorage.getItem(NOTES_KEY)||'{}'));}catch(e){$('notes-status').textContent=e.message;}};
 $('restore-notes').onclick=()=>$('notes-file').click();
 $('notes-file').onchange=async e=>{try{const file=e.target.files[0];if(!file)return;if(file.size>5000000)throw Error('Backup exceeds 5 MB.');const data=JSON.parse(await file.text());if(data.version!==1)throw Error('Invalid backup.');await importNotes(data.deliveryNotes);}catch(err){$('notes-status').textContent=err.message;}finally{e.target.value='';}};
 syncNotes();setInterval(syncNotes,5000);window.addEventListener('online',syncNotes);
});
