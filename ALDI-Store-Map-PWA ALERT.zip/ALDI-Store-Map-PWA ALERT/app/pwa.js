const status=document.getElementById('pwa-status'),install=document.getElementById('install-app');
let installPrompt;
function connectionStatus(){status.textContent=navigator.onLine?'':'Offline: store search and coordinates work. Map backgrounds and directions need internet.';status.hidden=navigator.onLine;}
window.addEventListener('online',connectionStatus);window.addEventListener('offline',connectionStatus);connectionStatus();
window.addEventListener('beforeinstallprompt',event=>{event.preventDefault();installPrompt=event;install.hidden=false;});
install.addEventListener('click',async()=>{if(!installPrompt)return;await installPrompt.prompt();await installPrompt.userChoice;installPrompt=null;install.hidden=true;});
window.addEventListener('appinstalled',()=>{install.hidden=true;installPrompt=null;});
if('serviceWorker' in navigator && window.isSecureContext){
 navigator.serviceWorker.register('./sw.js').then(()=>navigator.serviceWorker.ready).then(()=>{document.getElementById('offline-ready').textContent='Store data saved for offline use.';}).catch(()=>{document.getElementById('offline-ready').textContent='Offline setup failed. Reload while the local server is running.';});
}else{document.getElementById('offline-ready').textContent='Run START-WINDOWS.cmd or serve this app over HTTPS to enable installation and offline access.';}
