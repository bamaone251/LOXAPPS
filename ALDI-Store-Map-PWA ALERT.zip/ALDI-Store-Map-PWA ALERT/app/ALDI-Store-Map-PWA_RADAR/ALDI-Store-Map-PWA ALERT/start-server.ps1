param([int]$Port = 8766, [switch]$NoBrowser)
$ErrorActionPreference = 'Stop'
$root = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot 'app'))
$listener = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback, $Port)
$types = @{'.html'='text/html; charset=utf-8';'.js'='text/javascript; charset=utf-8';'.css'='text/css; charset=utf-8';'.json'='application/json';'.webmanifest'='application/manifest+json';'.geojson'='application/geo+json';'.csv'='text/csv; charset=utf-8';'.png'='image/png'}
try {
 $listener.Start()
 $url = "http://127.0.0.1:$Port/"
 Write-Host "ALDI Store Map is running at $url"
 Write-Host 'Keep this window open while using the app. Press Ctrl+C to stop.'
 if (-not $NoBrowser) { Start-Process $url }
 while ($true) {
  $client = $listener.AcceptTcpClient()
  try {
   $client.ReceiveTimeout = 5000
   $stream = $client.GetStream()
   $reader = [IO.StreamReader]::new($stream, [Text.Encoding]::ASCII, $false, 1024, $true)
   $line = $reader.ReadLine()
   if (-not $line) { continue }
   $parts = $line.Split(' ')
   while ($reader.ReadLine()) {}
   $method = $parts[0]
   $relative = [Uri]::UnescapeDataString(($parts[1].Split('?')[0])).TrimStart('/')
   if (-not $relative) { $relative = 'index.html' }
   $file = [IO.Path]::GetFullPath((Join-Path $root $relative))
   $status = '200 OK'
   $mime = $types[[IO.Path]::GetExtension($file)]
   if (-not $mime) { $mime = 'application/octet-stream' }
   if ($method -notin @('GET','HEAD')) { $status='405 Method Not Allowed' }
   elseif (-not $file.StartsWith($root + [IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)) { $status='403 Forbidden' }
   elseif (-not [IO.File]::Exists($file)) { $status='404 Not Found' }
   if ($status -eq '200 OK') { $body=[IO.File]::ReadAllBytes($file) }
   else { $body=[Text.Encoding]::UTF8.GetBytes($status);$mime='text/plain' }
   $header="HTTP/1.1 $status`r`nContent-Type: $mime`r`nContent-Length: $($body.Length)`r`nCache-Control: no-cache`r`nX-Content-Type-Options: nosniff`r`nConnection: close`r`n`r`n"
   $bytes=[Text.Encoding]::ASCII.GetBytes($header)
   $stream.Write($bytes,0,$bytes.Length)
   if ($method -ne 'HEAD') { $stream.Write($body,0,$body.Length) }
   $stream.Flush()
  } catch { Write-Warning $_.Exception.Message }
  finally { $client.Close() }
 }
} catch { Write-Host "Cannot start the app: $($_.Exception.Message)"; exit 1 }
finally { $listener.Stop() }
