import json, os, sqlite3
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import unquote
DB=os.environ.get('NOTES_DB','/data/notes.sqlite3')
os.makedirs(os.path.dirname(os.path.abspath(DB)),exist_ok=True)
with sqlite3.connect(DB) as db:
 db.execute('CREATE TABLE IF NOT EXISTS notes (code TEXT PRIMARY KEY, blocked INTEGER NOT NULL, notes TEXT NOT NULL, revision INTEGER NOT NULL)')
def valid(code,n):
 return isinstance(code,str) and 0<len(code)<=180 and isinstance(n,dict) and type(n.get('blocked')) is bool and isinstance(n.get('notes'),str) and len(n['notes'])<=5000
class Handler(BaseHTTPRequestHandler):
 def reply(self,status,data):
  body=json.dumps(data).encode();self.send_response(status);self.send_header('Content-Type','application/json');self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
 def do_GET(self):
  if self.path!='/api/notes':return self.reply(404,{'error':'Not found'})
  with sqlite3.connect(DB) as db:
   data={c:dict(blocked=bool(b),notes=n,revision=v) for c,b,n,v in db.execute('SELECT * FROM notes')}
  self.reply(200,data)
 def do_POST(self):
  if self.headers.get('Content-Type','').split(';')[0]!='application/json':return self.reply(415,{'error':'JSON required'})
  try:
   length=int(self.headers.get('Content-Length','0'))
   if not 0<length<=5000000:return self.reply(413,{'error':'Request too large'})
   data=json.loads(self.rfile.read(length))
   with sqlite3.connect(DB,timeout=15) as db:
    db.execute('BEGIN IMMEDIATE')
    if self.path=='/api/import':
     if not isinstance(data,dict) or not all(valid(c,n) for c,n in data.items()):return self.reply(400,{'error':'Invalid backup'})
     for c,n in data.items():
      old=db.execute('SELECT blocked,notes FROM notes WHERE code=?',(c,)).fetchone()
      if old and old!=(int(n['blocked']),n['notes']):return self.reply(409,{'error':'Conflicting shared notes for '+c+'. Nothing imported.'})
     for c,n in data.items():db.execute('INSERT OR IGNORE INTO notes VALUES (?,?,?,1)',(c,int(n['blocked']),n['notes']))
    elif self.path.startswith('/api/notes/'):
     c=unquote(self.path[len('/api/notes/'):])
     if not valid(c,data) or type(data.get('revision')) is not int:return self.reply(400,{'error':'Invalid note'})
     row=db.execute('SELECT revision FROM notes WHERE code=?',(c,)).fetchone();rev=row[0] if row else 0
     if data['revision']!=rev:return self.reply(409,{'error':'Another user changed this location. Copy your draft, close and reopen the popup, then review and save again.'})
     db.execute('INSERT OR REPLACE INTO notes VALUES (?,?,?,?)',(c,int(data['blocked']),data['notes'],rev+1))
    else:return self.reply(404,{'error':'Not found'})
    db.commit()
   self.reply(200,{'saved':True})
  except (ValueError,TypeError):self.reply(400,{'error':'Invalid request'})
  except Exception:self.reply(500,{'error':'Server could not save. Try again.'})
ThreadingHTTPServer(('0.0.0.0',int(os.environ.get('API_PORT','8000'))),Handler).serve_forever()
