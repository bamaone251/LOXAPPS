ALDI STORE MAP v5 — SHARED DELIVERY NOTES

Start with SHARED-NOTES.md. Deploy both Docker services using compose.yaml (port 8677).
Delivery notes and unable-to-receive status sync via the VPS. Custom locations remain browser-local.
The static Windows launcher does not run the shared notes API.
