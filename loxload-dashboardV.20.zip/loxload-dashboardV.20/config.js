/* ==========================================================
   Loxload Dashboard — configuration
   This is the only file you should need to edit.
   ========================================================== */

window.DASHBOARD_CONFIG = {
  title: "Loxload Dashboard",

  // Sources offered in every frame dropdown. Add more entries here.
  apps: [
      { key: "f3", name: "Yard",      url: "https://yard.loxload.com/" },
  { key: "f10", name: "Yard Notes",      url: "https://requests.loxload.com/" },
    { key: "f1", name: "PLB Log",   url: "https://plblog.loxload.com/" },
    { key: "f2", name: "Store Map", url: "https://map.loxload.com/" },
    
    { key: "f4", name: "Shift Notes",     url: "https://comms.loxload.com/" },
    
    { key: "f6", name: "Efficiency", url: "https://ops.loxload.com/" },
    { key: "f7", name: "Error Log", url: "https://error.loxload.com/" },
    { key: "f8", name: "Equipment", url: "https://equipment.loxload.com/" },
    { key: "f12", name: "Loader Times", url: "https://loadmap.loxload.com/" },
   
   
    { key: "f13", name: "Load Map", url: "https://loadmap.loxload.com/" },
    { key: "f5", name: "ESPN",   url: "https://piped.andytalbert.com/" },
 
   
    
  ],

  // Default five frames: Yard + Comms above PL Blog, Store Map and Tracker.
  layout: ["f3", "f13", "f1", "f7", "f2"],

  // Querystring URLs are only accepted for these hosts (subdomains included).
  allowedHosts: ["loxload.com", "andytalbert.com", "bamaone251.github.io"],

  // Browser features the framed apps may use.
  iframeAllow: "geolocation; fullscreen; clipboard-read; clipboard-write; microphone; camera; autoplay",

  // Wallboard: reload every panel every N hours to clear memory leaks (0 = off)
  autoReloadHours: .1,
};
