# Loxload adjustable dashboard

## Run on your VPS
Extract this ZIP, enter the loxload-dashboard folder, then run:

```bash
sudo docker compose up -d --build
```

Open http://YOUR-VPS-IP:4171 or keep your existing HTTPS reverse proxy pointed to port 4171. To use another port, create a .env file containing PORT=YOUR_PORT. The existing Compose service name is preserved.

## Controls
- Each frame's dropdown includes PL Blog, Store Map, Yard, Comms, Tracker, Operations, Error Log, Equipment, Fishing and QUAD. Multiple frames can show the same source.
- Click Edit layout. Drag the ✥ handle to move a frame. Drag any edge or corner to resize in either direction. The mint lower-right corner resizes both dimensions. Click Done editing when finished.
- Frames move freely and can overlap. Shrink or move neighboring frames to create space. The canvas scrolls on smaller screens.
- + Add frame creates a frame and turns on editing. × deletes a frame.
- − / + adjust embedded page zoom. ↻ reloads a frame; ↗ opens its source separately. ⤢ maximizes/restores; Esc restores.
- Reset layout restores the original five positions after confirmation.
- Layout, sources and zoom save automatically in this browser for this dashboard address. They are not shared between devices. Clearing browser storage removes them.
- All reloads every frame. Automatic reload remains six hours, configurable in config.js. Fullscreen and screen wake lock are requested where supported.
- Add future source options in config.js. Querystring overrides such as ?f3=https://yard.loxload.com/ are accepted only for allowed hosts.

## Updating
Replace the project files together and run sudo docker compose up -d --build. Hard-refresh the dashboard once after updating. This release uses new layout storage; old layout settings are not migrated.

## Embedded source permissions
Each source must permit your dashboard origin in its Content-Security-Policy frame-ancestors directive. A conflicting X-Frame-Options header or other source restrictions can prevent embedding. Configure this on each source's server, including ops, error and equipment. The dashboard cannot override source security headers. Use ↗ to open a source separately if it refuses to load. Test from the real HTTPS dashboard domain with your normal app logins.

The Dockerfile now copies all four frontend files and includes the previously missing nginx.conf.
