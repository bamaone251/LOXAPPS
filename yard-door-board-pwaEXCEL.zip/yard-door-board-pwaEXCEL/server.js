const express = require('express');
const http = require('http');
const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');
const ExcelJS = require('exceljs');
const PDFDocument = require('pdfkit');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const PORT = Number(process.env.PORT || 3030);
const DATA_DIR = path.join(__dirname, 'data');
const ARCHIVE_DIR = path.join(__dirname, 'archives');
fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(ARCHIVE_DIR, { recursive: true });

const db = new Database(path.join(DATA_DIR, 'yard-board.db'));
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS doors (
  door INTEGER PRIMARY KEY,
  trailer TEXT,
  run TEXT,
  status TEXT NOT NULL DEFAULT 'Empty',
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  day_key TEXT NOT NULL,
  door INTEGER NOT NULL,
  trailer TEXT,
  run TEXT,
  action TEXT NOT NULL,
  status TEXT NOT NULL,
  actor TEXT,
  notes TEXT,
  created_at TEXT NOT NULL
);
`);

// Backward-compatible migration: Out of Service is a separate door flag so
// trailer/run/loading information is preserved when a door is disabled.
const doorColumns = db.prepare('PRAGMA table_info(doors)').all().map(c => c.name);
if (!doorColumns.includes('out_of_service')) {
  db.exec('ALTER TABLE doors ADD COLUMN out_of_service INTEGER NOT NULL DEFAULT 0');
}
if (!doorColumns.includes('version')) db.exec('ALTER TABLE doors ADD COLUMN version INTEGER NOT NULL DEFAULT 0');
if (!doorColumns.includes('status_since')) {
  db.exec('ALTER TABLE doors ADD COLUMN status_since TEXT');
  // Older records have no separate status timestamp; use their last update.
  db.exec('UPDATE doors SET status_since = updated_at');
}
db.exec(`CREATE TABLE IF NOT EXISTS pooled_trailers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  trailer TEXT NOT NULL COLLATE NOCASE UNIQUE,
  run TEXT,
  source_door INTEGER NOT NULL,
  pooled_at TEXT NOT NULL,
  version INTEGER NOT NULL DEFAULT 0
);`);

const nowIso = () => new Date().toISOString();
const dayKey = (d = new Date()) => {
  const parts = new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Chicago', year:'numeric', month:'2-digit', day:'2-digit' }).formatToParts(d);
  const get = t => parts.find(p => p.type === t)?.value;
  return `${get('year')}-${get('month')}-${get('day')}`;
};
const displayTime = iso => new Intl.DateTimeFormat('en-US', { timeZone:'America/Chicago', month:'numeric', day:'numeric', year:'2-digit', hour:'numeric', minute:'2-digit' }).format(new Date(iso));

const insertDoor = db.prepare('INSERT OR IGNORE INTO doors (door, trailer, run, status, updated_at) VALUES (?, NULL, NULL, ?, ?)');
for (let door=10; door<=49; door++) insertDoor.run(door, 'Empty', nowIso());
db.exec('UPDATE doors SET status_since = updated_at WHERE status_since IS NULL');

function getBoard() {
  return db.prepare('SELECT * FROM doors ORDER BY door').all();
}
function getPool() { return db.prepare('SELECT * FROM pooled_trailers ORDER BY pooled_at, id').all(); }
let revision = 0;
const instance = require('crypto').randomUUID();
function getState() { return { board:getBoard(), pool:getPool(), events:getEvents(), day:dayKey(), revision, instance, server_time:nowIso() }; }
function getEvents(day = dayKey()) {
  return db.prepare('SELECT * FROM events WHERE day_key=? ORDER BY id DESC').all(day);
}
function logEvent({door,trailer,run,action,status,actor,notes}) {
  db.prepare(`INSERT INTO events(day_key,door,trailer,run,action,status,actor,notes,created_at)
    VALUES(?,?,?,?,?,?,?,?,?)`).run(dayKey(), door, trailer || null, run || null, action, status, actor || null, notes || null, nowIso());
}
function setDoor(door, patch) {
  const cur = db.prepare('SELECT * FROM doors WHERE door=?').get(door);
  const next = {
    trailer: patch.trailer !== undefined ? patch.trailer : cur.trailer,
    run: patch.run !== undefined ? patch.run : cur.run,
    status: patch.status !== undefined ? patch.status : cur.status,
    out_of_service: patch.out_of_service !== undefined ? (patch.out_of_service ? 1 : 0) : cur.out_of_service,
  };
  const changedStatus = next.status !== cur.status || next.trailer !== cur.trailer;
  const stamp = nowIso();
  db.prepare('UPDATE doors SET trailer=?, run=?, status=?, out_of_service=?, updated_at=?, status_since=?, version=version+1 WHERE door=?').run(next.trailer || null, next.run || null, next.status, next.out_of_service, stamp, changedStatus ? stamp : cur.status_since, door);
  return db.prepare('SELECT * FROM doors WHERE door=?').get(door);
}
function broadcast() { revision++; io.emit('board:update', getState()); }

function validateDoor(door) { return Number.isInteger(door) && door >= 10 && door <= 49; }

function trailerConflict(trailer, door) {
  const occupied = db.prepare('SELECT door FROM doors WHERE door != ? AND lower(trim(trailer)) = lower(?)').get(door, trailer);
  if (occupied) return `Trailer ${trailer} is already on Door ${occupied.door}. Remove it there first.`;
  if (db.prepare('SELECT id FROM pooled_trailers WHERE trailer = ? COLLATE NOCASE').get(trailer)) return `Trailer ${trailer} is in the pooled trailer list. Dispatch it from that list before reusing this number.`;
  return null;
}

app.use(express.json({limit:'1mb'}));
app.use(express.static(path.join(__dirname, 'public')));
app.get('/manifest.webmanifest', (req,res)=>res.sendFile(path.join(__dirname,'manifest.webmanifest')));

app.get('/api/state', (req,res) => { res.set('Cache-Control', 'no-store'); res.json(getState()); });

// Every mutation must refer to the version the operator actually reviewed.
// Synchronous handlers keep this check and the write together on the event loop.
app.use('/api/doors/:door', (req,res,next) => {
  if (req.method !== 'POST') return next();
  const door = Number(req.params.door);
  if (!validateDoor(door)) return res.status(400).json({error:'Invalid door.'});
  const current = db.prepare('SELECT * FROM doors WHERE door=?').get(door);
  if (!Number.isInteger(req.body.expected_version)) return res.status(428).json({error:'Reload the app and reopen this door before saving.'});
  if (req.body.expected_version !== current.version) return res.status(409).json({code:'STALE_EDIT', error:'This door changed while you were editing. Cancel and reopen it to review the latest information.', state:getState()});
  next();
});

app.post('/api/doors/:door/place', (req,res) => {
  const door = Number(req.params.door); const trailer = String(req.body.trailer || '').trim(); const actor = String(req.body.actor || 'Yard Driver').trim();
  if (!validateDoor(door) || !trailer) return res.status(400).json({error:'Valid door and trailer number required.'});
  const cur = db.prepare('SELECT * FROM doors WHERE door=?').get(door);
  if (cur.out_of_service) return res.status(409).json({error:'Door is OUT OF SERVICE. Return it to service before placing a trailer.'});
  if (cur.status !== 'Empty') return res.status(409).json({error:'Door is not empty.'});
  const conflict = trailerConflict(trailer, door);
  if (conflict) return res.status(409).json({error:conflict});
  const updated = setDoor(door, {trailer, run:null, status:'Available'});
  logEvent({door,trailer,run:null,action:'Trailer placed on door',status:'Available',actor});
  broadcast(); res.json({...updated, state:getState()});
});

app.post('/api/doors/:door/loading', (req,res) => {
  const door = Number(req.params.door); const run = String(req.body.run || '').trim(); const actor = String(req.body.actor || 'Load Desk').trim();
  if (!validateDoor(door) || !run) return res.status(400).json({error:'Run number required.'});
  const cur = db.prepare('SELECT * FROM doors WHERE door=?').get(door);
  if (cur.out_of_service) return res.status(409).json({error:'Door is OUT OF SERVICE. Return it to service before starting a load.'});
  if (cur.status !== 'Available') return res.status(409).json({error:'Trailer must be Available before loading starts.'});
  const updated = setDoor(door, {run, status:'Loading'});
  logEvent({door,trailer:cur.trailer,run,action:'Run assigned / loading started',status:'Loading',actor});
  broadcast(); res.json({...updated, state:getState()});
});

app.post('/api/doors/:door/complete', (req,res) => {
  const door = Number(req.params.door); const actor = String(req.body.actor || 'Load Desk').trim();
  if (!validateDoor(door)) return res.status(400).json({error:'Invalid door.'});
  const cur = db.prepare('SELECT * FROM doors WHERE door=?').get(door);
  if (cur.status !== 'Loading') return res.status(409).json({error:'Door must be Loading first.'});
  const updated = setDoor(door, {status:'Loading Complete'});
  logEvent({door,trailer:cur.trailer,run:cur.run,action:'Loading completed',status:'Loading Complete',actor});
  broadcast(); res.json({...updated, state:getState()});
});

app.post('/api/doors/:door/remove', (req,res) => {
  const door = Number(req.params.door); const disposition = String(req.body.disposition || ''); const actor = String(req.body.actor || 'Yard Driver').trim();
  if (!validateDoor(door) || !['Pooled','Dispatched'].includes(disposition)) return res.status(400).json({error:'Choose Pooled or Dispatched.'});
  const cur = db.prepare('SELECT * FROM doors WHERE door=?').get(door);
  if (cur.status !== 'Loading Complete') return res.status(409).json({error:'Loading must be complete before trailer removal.'});
  if (disposition === 'Pooled' && db.prepare('SELECT id FROM pooled_trailers WHERE trailer = ? COLLATE NOCASE').get(cur.trailer)) {
    return res.status(409).json({error:'This trailer is already pooled. Correct the duplicate record before moving it.'});
  }
  const updated = db.transaction(() => {
    if (disposition === 'Pooled') db.prepare('INSERT INTO pooled_trailers(trailer,run,source_door,pooled_at) VALUES(?,?,?,?)').run(cur.trailer, cur.run, door, nowIso());
    logEvent({door,trailer:cur.trailer,run:cur.run,action:`Trailer removed - ${disposition}`,status:disposition,actor});
    return setDoor(door, {trailer:null,run:null,status:'Empty'});
  })();
  broadcast(); res.json({...updated, state:getState()});
});

app.post('/api/doors/:door/service', (req,res) => {
  const door = Number(req.params.door);
  const outOfService = Boolean(req.body.out_of_service);
  const actor = String(req.body.actor || 'Load Desk').trim();
  const notes = String(req.body.notes || '').trim();
  if (!validateDoor(door)) return res.status(400).json({error:'Invalid door.'});
  const cur = db.prepare('SELECT * FROM doors WHERE door=?').get(door);
  const updated = setDoor(door, {out_of_service: outOfService});
  logEvent({
    door, trailer:cur.trailer, run:cur.run,
    action: outOfService ? 'Door marked OUT OF SERVICE' : 'Door returned to service',
    status: outOfService ? 'Out of Service' : cur.status,
    actor, notes
  });
  broadcast(); res.json({...updated, state:getState()});
});

app.post('/api/doors/:door/edit', (req,res) => {
  const door = Number(req.params.door);
  const actor = String(req.body.actor || 'Load Desk').trim();
  let trailer = String(req.body.trailer || '').trim();
  let run = String(req.body.run || '').trim();
  const status = String(req.body.status || '').trim();
  const outOfService = Boolean(req.body.out_of_service);
  const validStatuses = ['Empty','Available','Loading','Loading Complete'];

  if (!validateDoor(door)) return res.status(400).json({error:'Invalid door.'});
  if (!validStatuses.includes(status)) return res.status(400).json({error:'Invalid status.'});

  if (status === 'Empty') { trailer = ''; run = ''; }
  if (status === 'Available') {
    if (!trailer) return res.status(400).json({error:'Available doors require a trailer number.'});
    run = '';
  }
  if ((status === 'Loading' || status === 'Loading Complete') && (!trailer || !run)) {
    return res.status(400).json({error:'Loading and Loading Complete require both a trailer number and run number.'});
  }

  const conflict = trailer && trailerConflict(trailer, door);
  if (conflict) return res.status(409).json({error:conflict});
  const cur = db.prepare('SELECT * FROM doors WHERE door=?').get(door);
  const updated = setDoor(door, {
    trailer: trailer || null,
    run: run || null,
    status,
    out_of_service: outOfService
  });

  const before = `Trailer ${cur.trailer || '—'}, Run ${cur.run || '—'}, ${cur.status}${cur.out_of_service ? ', OUT OF SERVICE' : ''}`;
  const after = `Trailer ${updated.trailer || '—'}, Run ${updated.run || '—'}, ${updated.status}${updated.out_of_service ? ', OUT OF SERVICE' : ''}`;
  logEvent({
    door,
    trailer: updated.trailer,
    run: updated.run,
    action: 'Door information manually edited',
    status: updated.out_of_service ? 'Out of Service' : updated.status,
    actor,
    notes: `${before} → ${after}`
  });
  broadcast();
  res.json({...updated, state:getState()});
});

app.post('/api/doors/:door/clear', (req,res) => {
  const door = Number(req.params.door); const actor = String(req.body.actor || 'Supervisor').trim();
  if (!validateDoor(door)) return res.status(400).json({error:'Invalid door.'});
  const cur = db.prepare('SELECT * FROM doors WHERE door=?').get(door);
  logEvent({door,trailer:cur.trailer,run:cur.run,action:'Door manually cleared',status:'Empty',actor});
  const updated = setDoor(door, {trailer:null,run:null,status:'Empty'});
  broadcast(); res.json({...updated, state:getState()});
});

app.post('/api/pool/:id/dispatch', (req,res) => {
  const row = db.prepare('SELECT * FROM pooled_trailers WHERE id=?').get(Number(req.params.id));
  if (!row) return res.status(409).json({code:'STALE_EDIT', error:'This pooled trailer has already been moved. Cancel and review the current list.', state:getState()});
  if (!Number.isInteger(req.body.expected_version)) return res.status(428).json({error:'Reload the app before dispatching.'});
  if (req.body.expected_version !== row.version) return res.status(409).json({code:'STALE_EDIT', error:'This pooled trailer changed. Cancel and reopen it.', state:getState()});
  db.transaction(() => {
    db.prepare('DELETE FROM pooled_trailers WHERE id=?').run(row.id);
    logEvent({door:row.source_door, trailer:row.trailer, run:row.run, action:'Pooled trailer dispatched', status:'Dispatched', actor:String(req.body.actor || 'Yard Driver').trim(), notes:'Dispatched from the pool; door number is the original source door.'});
  })();
  broadcast(); res.json({state:getState()});
});

async function buildExcel(day = dayKey()) {
  const wb = new ExcelJS.Workbook();
  wb.creator = 'Yard Door Board';
  const board = wb.addWorksheet('Current Board');
  board.columns = [
    {header:'Door',key:'door',width:10},{header:'Trailer #',key:'trailer',width:18},{header:'Run #',key:'run',width:15},{header:'Status',key:'status',width:22},{header:'Out of Service',key:'oos',width:16},{header:'Updated',key:'updated',width:23}
  ];
  for (const row of getBoard()) board.addRow({...row, oos:row.out_of_service ? 'YES' : '', updated:displayTime(row.updated_at)});
  board.getRow(1).font = {bold:true};
  const pool = wb.addWorksheet('Pooled Trailers');
  pool.columns = [
    {header:'Trailer #',key:'trailer',width:20},{header:'Run #',key:'run',width:18},
    {header:'From Door',key:'source_door',width:14},{header:'Pooled Since',key:'since',width:25}
  ];
  getPool().forEach(row => pool.addRow({...row, since:displayTime(row.pooled_at)}));
  pool.getRow(1).font = {bold:true};
  const hist = wb.addWorksheet('Daily Activity');
  hist.columns = [
    {header:'Time',key:'time',width:23},{header:'Door',key:'door',width:10},{header:'Trailer #',key:'trailer',width:20},{header:'Run #',key:'run',width:11},{header:'Action',key:'action',width:32},{header:'Status',key:'status',width:22},{header:'Actor',key:'actor',width:18},{header:'Notes',key:'notes',width:42}
  ];
  for (const e of [...getEvents(day)].reverse()) hist.addRow({time:displayTime(e.created_at), ...e});
  hist.getRow(1).font = {bold:true};
  return wb;
}

function renderPdf(stream, day = dayKey(), boardRows = getBoard(), events = getEvents(day)) {
  const doc = new PDFDocument({size:'LETTER', margin:32, layout:'landscape'});
  doc.pipe(stream);
  doc.fontSize(18).text(`DAILY YARD BOARD — ${day}`, {align:'center'});
  doc.moveDown(.5).fontSize(9);
  const x=[32,72,155,230,350,455,570];
  const headers=['Door','Trailer #','Run #','Status','Out of Service','Updated'];
  headers.forEach((h,i)=>doc.font('Helvetica-Bold').text(h,x[i],doc.y,{width:x[i+1]-x[i]-5}));
  doc.moveDown(.7); let y=doc.y;
  for (const r of boardRows) {
    if (y > 520) { doc.addPage({size:'LETTER',layout:'landscape',margin:32}); y=40; }
    doc.font('Helvetica').fontSize(8);
    const vals=[r.door,r.trailer||'',r.run||'',r.status,r.out_of_service?'YES':'',displayTime(r.updated_at)];
    vals.forEach((v,i)=>doc.text(String(v),x[i],y,{width:(x[i+1]||750)-x[i]-5}));
    y += 14;
  }
  doc.addPage({size:'LETTER',layout:'landscape',margin:32});
  doc.font('Helvetica-Bold').fontSize(14).text('Daily Activity');
  doc.moveDown(.5); y=doc.y;
  const hx=[32,130,170,255,330,500,620];
  const hh=['Time','Door','Trailer','Run','Action','Status','Actor'];
  hh.forEach((h,i)=>doc.font('Helvetica-Bold').fontSize(8).text(h,hx[i],y,{width:(hx[i+1]||760)-hx[i]-4})); y+=14;
  for (const e of [...events].reverse()) {
    if (y > 520) { doc.addPage({size:'LETTER',layout:'landscape',margin:32}); y=40; }
    const vals=[displayTime(e.created_at),e.door,e.trailer||'',e.run||'',e.action,e.status,e.actor||''];
    vals.forEach((v,i)=>doc.font('Helvetica').fontSize(7).text(String(v),hx[i],y,{width:(hx[i+1]||760)-hx[i]-4})); y+=13;
  }
  doc.addPage({size:'LETTER',layout:'landscape',margin:32});
  doc.font('Helvetica-Bold').fontSize(14).text('Pooled Trailers — Still On Site');
  doc.moveDown().font('Helvetica').fontSize(10);
  const pool = getPool();
  if (!pool.length) doc.text('No pooled trailers.');
  for (const row of pool) doc.text(`Trailer ${row.trailer} | Run ${row.run || '—'} | From Door ${row.source_door} | Pooled ${displayTime(row.pooled_at)}`);
  doc.end();
}


function excelArchiveFilename(day) {
  const [y,m,d] = day.split('-');
  return `DAILY_YARD_ACTIVITY_${m}-${d}-${y.slice(2)}.xlsx`;
}

async function saveExcelArchive(day = dayKey()) {
  const filename = excelArchiveFilename(day);
  const out = path.join(ARCHIVE_DIR, filename);
  if (fs.existsSync(out)) return out;
  const wb = await buildExcel(day);
  await wb.xlsx.writeFile(out);
  console.log(`Saved Excel activity archive for ${day} to ${out}`);
  return out;
}

function listExcelArchives() {
  return fs.readdirSync(ARCHIVE_DIR, { withFileTypes: true })
    .filter(entry => entry.isFile() && /^DAILY_YARD_ACTIVITY_\d{2}-\d{2}-\d{2}\.xlsx$/i.test(entry.name))
    .map(entry => {
      const full = path.join(ARCHIVE_DIR, entry.name);
      const st = fs.statSync(full);
      return { name: entry.name, size: st.size, modified: st.mtime.toISOString() };
    })
    .sort((a,b) => b.name.localeCompare(a.name));
}

app.get('/api/archives', (req,res) => {
  res.json({ archives: listExcelArchives() });
});

app.get('/api/archives/:filename', (req,res) => {
  const filename = path.basename(String(req.params.filename || ''));
  if (!/^DAILY_YARD_ACTIVITY_\d{2}-\d{2}-\d{2}\.xlsx$/i.test(filename)) {
    return res.status(400).json({error:'Invalid archive filename.'});
  }
  const full = path.join(ARCHIVE_DIR, filename);
  if (!fs.existsSync(full)) return res.status(404).json({error:'Archive not found.'});
  res.download(full, filename);
});

app.get('/api/export/excel', async (req,res) => {
  const day=dayKey(); const wb=await buildExcel(day);
  res.setHeader('Content-Type','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition',`attachment; filename="YARD_BOARD_${day}.xlsx"`);
  await wb.xlsx.write(res); res.end();
});
app.get('/api/export/pdf', (req,res) => {
  const day=dayKey();
  res.setHeader('Content-Type','application/pdf');
  res.setHeader('Content-Disposition',`attachment; filename="YARD_BOARD_${day}.pdf"`);
  renderPdf(res,day);
});


let excelArchiveBusy = false;
setInterval(async () => {
  const now = new Date();
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: 'America/Chicago',
    hour12: false,
    hour: '2-digit',
    minute: '2-digit'
  }).formatToParts(now);
  const get = type => parts.find(p => p.type === type)?.value;
  const hour = Number(get('hour'));
  const minute = Number(get('minute'));

  // Save once per day at 11:55 PM Central. Checking through 11:59 makes
  // this resilient to a brief process pause/restart during the target minute.
  if (hour === 23 && minute >= 55 && !excelArchiveBusy) {
    excelArchiveBusy = true;
    try {
      await saveExcelArchive(dayKey(now));
    } catch (err) {
      console.error('Unable to save nightly Excel archive:', err);
    } finally {
      excelArchiveBusy = false;
    }
  }
}, 15000);

let lastDay = dayKey();
function archiveDay(completedDay) {
  const events = getEvents(completedDay);
  const boardSnapshot = getBoard();
  const [y,m,d] = completedDay.split('-');
  const out = path.join(ARCHIVE_DIR, `DAILY_YARD_BOARD_${m}-${d}-${y.slice(2)}.pdf`);
  const stream = fs.createWriteStream(out);
  stream.on('error', err => console.error('Unable to save daily PDF archive:', err));
  renderPdf(stream, completedDay, boardSnapshot, events);
  // Day boundaries change the activity view, never the physical yard inventory.
  broadcast();
  console.log(`Archived ${completedDay} to ${out}; doors and pooled trailers carried forward.`);
  return new Promise((resolve,reject) => { stream.on('finish', resolve); stream.on('error', reject); });
}
setInterval(() => {
  const today=dayKey();
  if (today !== lastDay) { const completed=lastDay; lastDay=today; archiveDay(completed).catch(err => console.error('Daily archive failed:', err)); }
}, 15000);

io.on('connection', socket => socket.emit('board:update', getState()));
server.listen(PORT, '0.0.0.0', () => console.log(`Yard Door Board running on port ${PORT}`));
module.exports = { archiveDay };
