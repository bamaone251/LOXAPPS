const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { spawn } = require('node:child_process');
const vm = require('node:vm');
const root = path.resolve(__dirname, '..');

test('migration, conflicts, status timers, pool lifecycle, exports and midnight carryover', async () => {
  const dir = fs.mkdtempSync(path.join(root, '.test-'));
  fs.copyFileSync(path.join(root, 'server.js'), path.join(dir, 'server.js'));
  fs.mkdirSync(path.join(dir, 'data'));
  const Database = require('better-sqlite3');
  const legacy = new Database(path.join(dir, 'data/yard-board.db'));
  legacy.exec("CREATE TABLE doors (door INTEGER PRIMARY KEY, trailer TEXT, run TEXT, status TEXT NOT NULL, updated_at TEXT NOT NULL, out_of_service INTEGER NOT NULL DEFAULT 0); INSERT INTO doors VALUES(49,'LEGACY','R49','Loading','2026-10-01T12:00:00.000Z',1);");
  legacy.close();
  fs.writeFileSync(path.join(dir, 'harness.js'), "const app=require('./server'); process.on('message', async day => { await app.archiveDay(day); process.send('archived'); });");
  const child = spawn(process.execPath, [path.join(dir, 'harness.js')], { env: { ...process.env, PORT: '31379' }, stdio: ['ignore', 'pipe', 'pipe', 'ipc'] });
  let errors = '';
  child.stderr.on('data', chunk => { errors += chunk; });
  try {
    await new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error(`Server startup timed out: ${errors}`)), 60000);
      child.stdout.on('data', () => { clearTimeout(timer); resolve(); });
      child.once('exit', code => { clearTimeout(timer); reject(new Error(`Server exited ${code}: ${errors}`)); });
    });
    const getState = async () => (await fetch('http://127.0.0.1:31379/api/state')).json();
    const migrated = (await getState()).board.find(d => d.door === 49);
    assert.equal(migrated.status_since, '2026-10-01T12:00:00.000Z');
    assert.equal(migrated.version, 0);
    const post = async (door, action, body) => {
      const current = (await getState()).board.find(d => d.door === door);
      const r = await fetch(`http://127.0.0.1:31379/api/doors/${door}/${action}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({expected_version:current.version,...body}) });
      return { status: r.status, body: await r.json() };
    };
    assert.equal((await post(10, 'place', { trailer: ' AbC123 ' })).status, 200);
    assert.equal((await post(11, 'place', { trailer: 'abc123' })).status, 409);
    const conflict = await post(11, 'edit', { trailer: ' ABC123 ', status: 'Available' });
    assert.equal(conflict.status, 409);
    assert.match(conflict.body.error, /Door 10/);
    assert.equal((await post(10, 'edit', { trailer: 'AbC123', run: 'RUN1', status: 'Loading' })).status, 200);
    const beforeCorrection = (await getState()).board.find(d => d.door === 10);
    assert.equal((await post(10, 'edit', { trailer: 'AbC123', run: 'CORRECTED', status: 'Loading' })).status, 200);
    assert.equal((await getState()).board.find(d => d.door === 10).status_since, beforeCorrection.status_since);
    const stale = await post(10, 'edit', {expected_version:beforeCorrection.version, trailer:'AbC123',run:'OLD',status:'Loading'});
    assert.equal(stale.status, 409);
    assert.equal(stale.body.code, 'STALE_EDIT');
    assert.equal((await post(10, 'clear', {expected_version:beforeCorrection.version})).status, 409);
    assert.equal((await post(10, 'service', {expected_version:null, out_of_service:true})).status, 428);
    assert.equal((await post(10, 'edit', { trailer: 'NEW456', run: 'RUN2', status: 'Loading Complete' })).status, 200);
    let state = await (await fetch('http://127.0.0.1:31379/api/state')).json();
    assert.equal(state.board.find(d => d.door === 10).trailer, 'NEW456');
    assert.equal(state.board.find(d => d.door === 10).run, 'RUN2');
    assert.equal(state.board.find(d => d.door === 11).status, 'Empty');
    assert.equal(state.events.length, 4);
    assert.equal((await post(11, 'place', { trailer: 'abc123' })).status, 200);
    assert.equal((await post(10, 'remove', { disposition: 'Pooled' })).status, 200);
    assert.equal((await post(12, 'place', { trailer: 'new456' })).status, 409);
    assert.equal((await post(12, 'edit', { trailer: 'new456', status:'Available' })).status, 409);
    state = await getState();
    assert.equal(state.pool.length, 1);
    assert.equal(state.pool[0].run, 'RUN2');
    assert.equal(state.board.find(d => d.door === 10).status, 'Empty');
    const beforeMidnight = state;
    const archived = new Promise(resolve => child.once('message', resolve));
    child.send('2026-10-14');
    await archived;
    const afterMidnight = await getState();
    assert.deepEqual(afterMidnight.board, beforeMidnight.board);
    assert.deepEqual(afterMidnight.pool, beforeMidnight.pool);
    assert.ok(fs.statSync(path.join(dir, 'archives/DAILY_YARD_BOARD_10-14-26.pdf')).size > 1000);
    const workbook = new (require('exceljs').Workbook)();
    await workbook.xlsx.load(await (await fetch('http://127.0.0.1:31379/api/export/excel')).arrayBuffer());
    assert.equal(workbook.getWorksheet('Pooled Trailers').getCell('A2').value, 'NEW456');
    const pool = state.pool[0];
    const dispatch = async () => fetch(`http://127.0.0.1:31379/api/pool/${pool.id}/dispatch`, {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({expected_version:pool.version,actor:'Test Driver'})});
    assert.equal((await dispatch()).status, 200);
    assert.equal((await dispatch()).status, 409);
    assert.equal((await getState()).pool.length, 0);
    assert.equal((await post(12, 'place', { trailer: 'new456' })).status, 200);
    const simultaneous = await Promise.all([post(13, 'place', { trailer: 'RACE' }), post(14, 'place', { trailer: 'race' })]);
    assert.deepEqual(simultaneous.map(r => r.status).sort(), [200, 409]);
  } finally {
    const exited = child.exitCode !== null ? Promise.resolve() : new Promise(resolve => child.once('exit', resolve));
    child.kill();
    await exited;
    assert.equal(path.dirname(path.resolve(dir)), root);
    assert.ok(path.basename(dir).startsWith('.test-'));
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test('client connection guards, edits, stale versions, search, timers and pool dispatch', async () => {
  const elements = new Map();
  function element(selector) {
    if (!elements.has(selector)) elements.set(selector, { value: '', handlers: {}, classList: { add() {}, remove() {}, toggle() {} }, addEventListener(event, fn) { this.handlers[event] = fn; }, querySelectorAll() { return []; }, showModal() {}, close() {}, focus() {} });
    return elements.get(selector);
  }
  let response;
  let requests = 0;
  let submitted;
  const socketHandlers = {};
  const context = vm.createContext({
    document: { querySelector: element, querySelectorAll: () => [], body: { dataset: {} } },
    localStorage: { getItem: () => '', setItem() {} },
    io: () => ({ on(event, callback) { socketHandlers[event] = callback; } }),
    fetch: (url, options) => { requests++; submitted={url, body:JSON.parse(options.body)}; return Promise.resolve(response); },
    navigator: {}, window: { addEventListener() {}, matchMedia: () => ({ matches: false }), navigator: {} },
    setTimeout: () => 0, clearTimeout() {}, setInterval() {}
  });
  vm.runInContext(fs.readFileSync(path.join(root, 'public/app.js'), 'utf8'), context);
  vm.runInContext('openEdit(10)', context);
  assert.equal(vm.runInContext('pending', context), null);
  const snapshot = {instance:'test',revision:0,server_time:new Date().toISOString(),board:[{door:10,status:'Empty',version:0}],pool:[],events:[]};
  socketHandlers['board:update'](snapshot);
  assert.match(element('#connectionStatus').textContent, /Live/);
  vm.runInContext('openEdit(10)', context);
  element('#editStatus').value = 'Empty';
  element('#editTrailer').value = 'T123';
  element('#editTrailer').handlers.input({ target: element('#editTrailer') });
  assert.equal(element('#editStatus').value, 'Available');
  response = { ok: true, json: async () => ({state:{...snapshot, revision:1,board:[{door:10,trailer:'T123',status:'Available',version:1}]}}) };
  await element('#actionForm').handlers.submit({ preventDefault() {} });
  assert.equal(vm.runInContext('state.board[0].trailer', context), 'T123');
  assert.equal(submitted.body.expected_version, 0);
  vm.runInContext('openEdit(10)', context);
  response = { ok: false, json: async () => ({ error: 'Trailer is already on Door 11.' }) };
  await element('#actionForm').handlers.submit({ preventDefault() {} });
  assert.equal(element('#actionError').hidden, false);
  assert.match(element('#actionError').textContent, /Door 11/);
  socketHandlers['disconnect']();
  const beforeOfflineSave = requests;
  await element('#actionForm').handlers.submit({preventDefault() {}});
  assert.equal(requests, beforeOfflineSave);
  assert.equal(element('#submitAction').disabled, true);
  assert.match(element('#connectionStatus').textContent, /Changes paused/);
  socketHandlers['board:update']({...snapshot,revision:2,board:[{door:10,trailer:'T123',run:'RUN55',status:'Loading',version:2}]});
  assert.equal(vm.runInContext('pending.version', context), 1);
  response = {ok:false,json:async()=>({code:'STALE_EDIT',error:'Cancel and reopen this door.'})};
  await element('#actionForm').handlers.submit({preventDefault() {}});
  assert.equal(element('#submitAction').disabled, true);
  assert.equal(vm.runInContext('pending.stale', context), true);
  element('#search').value = 'run55';
  assert.equal(vm.runInContext('matchesSearch(state.board[0])', context), true);
  element('#search').value = 'missing';
  assert.equal(vm.runInContext('matchesSearch(state.board[0])', context), false);
  assert.match(vm.runInContext('elapsed(new Date(Date.now()+serverOffset-7500000).toISOString())', context), /2 hr 5 min/);
  socketHandlers['board:update']({...snapshot,revision:1});
  assert.equal(vm.runInContext('state.revision', context), 2);
  socketHandlers['board:update']({...snapshot,revision:3,pool:[{id:1,trailer:'POOL',run:'R1',source_door:10,version:0,pooled_at:new Date().toISOString()}]});
  vm.runInContext('openPoolDispatch(1)', context);
  response = {ok:true,json:async()=>({state:{...snapshot,revision:4}})};
  await element('#actionForm').handlers.submit({preventDefault() {}});
  assert.equal(submitted.url, '/api/pool/1/dispatch');
  assert.equal(submitted.body.expected_version, 0);
  assert.equal(vm.runInContext('state.pool.length', context), 0);
});
