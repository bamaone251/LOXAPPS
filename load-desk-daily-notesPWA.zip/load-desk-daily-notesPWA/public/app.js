const state = { day: null, sections: [], currentShift: 1, editId: null };
const $ = selector => document.querySelector(selector);
const $$ = selector => [...document.querySelectorAll(selector)];
let deferredInstallPrompt = null;

async function request(url, options = {}) {
  const isFormData = options.body instanceof FormData;
  const response = await fetch(url, {
    ...options,
    headers: isFormData ? { ...(options.headers || {}) } : { 'Content-Type': 'application/json', ...(options.headers || {}) }
  });
  if (response.status === 204) return null;
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.error || 'Request failed.');
  return body;
}

async function init() {
  try {
    const [config, today] = await Promise.all([request('/api/config'), request('/api/today')]);
    state.sections = config.sections;
    state.day = today.day;
    state.currentShift = today.currentShift;
    populateSelects();
    fillHeader();
    render();
    updateClock();
    setInterval(updateClock, 1000);
    bindEvents();
    setupPwa();
    if (Object.values(state.day.header).some(value => !String(value || '').trim())) openAssignments(true);
  } catch (error) {
    toast(error.message);
  }
}

function populateSelects() {
  for (const select of [$('#sectionInput'), $('#editSection')]) {
    select.replaceChildren(...state.sections.map(section => new Option(section, section)));
  }
}

function fillHeader() {
  for (const [field, value] of Object.entries(state.day.header)) {
    const summary = document.querySelector(`[data-assignment="${field}"]`);
    if (summary) summary.textContent = value || '—';
    const input = document.querySelector(`#assignmentsForm [name="${field}"]`);
    if (input) input.value = value;
  }
}

function render() {
  $('#filename').textContent = state.day.filename;
  $('#pdfButton').href = `/api/days/${state.day.date}/pdf`;
  const container = $('#sections');
  container.replaceChildren(...state.sections.map(renderSection));
}

function renderSection(section) {
  const entries = state.day.entries.filter(entry => entry.section === section);
  const wrapper = el('section', 'note-section');
  const header = el('div', 'note-section-header');
  const title = el('h2'); title.textContent = section;
  const count = el('span', 'count'); count.textContent = entries.length;
  header.append(title, count);
  const list = el('div', 'entry-list');
  if (!entries.length) {
    const empty = el('p', 'empty'); empty.textContent = 'No entries yet'; list.append(empty);
  } else {
    list.append(...entries.map(renderEntry));
  }
  wrapper.append(header, list);
  return wrapper;
}

function renderEntry(entry) {
  const article = el('article', `entry shift-${entry.shift}${entry.highlighted ? ' highlighted' : ''}`);
  const accent = el('div', 'entry-accent');
  const body = el('div');
  const meta = el('div', 'entry-meta');
  const timestamp = el('span'); timestamp.textContent = formatTimestamp(entry.createdAt);
  const shift = el('span'); shift.textContent = `${ordinal(entry.shift)} Shift`;
  meta.append(timestamp, shift);
  if (entry.enteredBy) { const by = el('span'); by.textContent = entry.enteredBy; meta.append(by); }
  if (entry.updatedAt !== entry.createdAt) { const edited = el('span'); edited.textContent = 'Edited'; meta.append(edited); }
  const text = el('p', 'entry-text'); text.textContent = entry.text;
  body.append(meta, text);
  if (entry.images?.length) body.append(renderPhotoGrid(entry));
  const actions = el('div', 'entry-actions');
  const highlight = actionButton(entry.highlighted ? 'Unhighlight' : 'Highlight', () => toggleHighlight(entry));
  const edit = actionButton('Edit', () => openEdit(entry));
  const remove = actionButton('Delete', () => deleteEntry(entry), 'delete');
  actions.append(highlight, edit, remove);
  article.append(accent, body, actions);
  return article;
}

function setupPwa() {
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/sw.js').catch(error => console.warn('Service worker registration failed:', error));
    });
  }

  const installButton = $('#installButton');
  const isStandalone = window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
  const isIos = /iphone|ipad|ipod/i.test(navigator.userAgent);

  if (isStandalone) return;

  window.addEventListener('beforeinstallprompt', event => {
    event.preventDefault();
    deferredInstallPrompt = event;
    installButton.hidden = false;
  });

  window.addEventListener('appinstalled', () => {
    deferredInstallPrompt = null;
    installButton.hidden = true;
    toast('Load Desk Notes installed.');
  });

  if (isIos) installButton.hidden = false;

  installButton.addEventListener('click', async () => {
    if (deferredInstallPrompt) {
      deferredInstallPrompt.prompt();
      await deferredInstallPrompt.userChoice;
      deferredInstallPrompt = null;
      installButton.hidden = true;
      return;
    }
    if (isIos) {
      toast('On iPhone/iPad: tap Share, then Add to Home Screen.');
      return;
    }
    toast('Use your browser menu and choose Install app or Add to Home Screen.');
  });
}

function bindEvents() {
  $('#noteForm').addEventListener('submit', addEntry);
  $('#editForm').addEventListener('submit', saveEdit);
  $('#archivesButton').addEventListener('click', openArchives);
  $('#editAssignmentsButton').addEventListener('click', () => openAssignments(false));
  $('#assignmentsForm').addEventListener('submit', saveAssignments);
  $('#cancelAssignmentsButton').addEventListener('click', () => $('#assignmentsDialog').close());
  $('#pictureInput').addEventListener('change', () => previewSelectedPictures($('#pictureInput'), $('#picturePreview')));
  $$('[data-close]').forEach(button => button.addEventListener('click', () => $(`#${button.dataset.close}`).close()));
}

async function addEntry(event) {
  event.preventDefault();
  const button = event.submitter;
  button.disabled = true;
  try {
    const pictures = [...$('#pictureInput').files];
    if (pictures.length > 4) throw new Error('Choose no more than four pictures.');
    const formData = new FormData();
    formData.append('section', $('#sectionInput').value);
    formData.append('enteredBy', $('#enteredByInput').value);
    formData.append('text', $('#noteInput').value);
    pictures.forEach(picture => formData.append('images', picture));
    const result = await request('/api/today/entries', {
      method: 'POST',
      body: formData
    });
    state.day.entries.push(result.entry);
    $('#noteInput').value = '';
    $('#pictureInput').value = '';
    $('#picturePreview').replaceChildren();
    render();
    toast(`Note added to ${result.entry.section}.`);
  } catch (error) { toast(error.message); }
  finally { button.disabled = false; }
}

function openAssignments(required) {
  fillHeader();
  $('#cancelAssignmentsButton').hidden = required;
  $('#assignmentsDialog').showModal();
}

async function saveAssignments(event) {
  event.preventDefault();
  const header = {};
  $$('#assignmentsForm input').forEach(input => { header[input.name] = input.value; });
  try {
    const result = await request('/api/today/header', { method: 'PATCH', body: JSON.stringify(header) });
    state.day.header = result.day.header;
    fillHeader();
    $('#assignmentsDialog').close();
    toast('Assignments saved.');
  } catch (error) { toast(error.message); }
}

async function toggleHighlight(entry) {
  try {
    const result = await request(`/api/entries/${entry.id}`, { method: 'PATCH', body: JSON.stringify({ highlighted: !entry.highlighted }) });
    replaceEntry(result.entry); render();
  } catch (error) { toast(error.message); }
}

function openEdit(entry) {
  state.editId = entry.id;
  $('#editSection').value = entry.section;
  $('#editEnteredBy').value = entry.enteredBy;
  $('#editText').value = entry.text;
  $('#editPictureInput').value = '';
  renderEditPictures(entry);
  $('#editDialog').showModal();
}

async function saveEdit(event) {
  event.preventDefault();
  try {
    let result = await request(`/api/entries/${state.editId}`, {
      method: 'PATCH',
      body: JSON.stringify({ section: $('#editSection').value, enteredBy: $('#editEnteredBy').value, text: $('#editText').value })
    });
    const pictures = [...$('#editPictureInput').files];
    const existingCount = result.entry.images?.length || 0;
    if (existingCount + pictures.length > 4) throw new Error(`This note can only have ${Math.max(0, 4 - existingCount)} more picture(s).`);
    if (pictures.length) {
      const formData = new FormData();
      pictures.forEach(picture => formData.append('images', picture));
      result = await request(`/api/entries/${state.editId}/images`, { method: 'POST', body: formData });
    }
    replaceEntry(result.entry); render(); $('#editDialog').close(); toast('Note updated.');
  } catch (error) { toast(error.message); }
}

async function deleteEntry(entry) {
  if (!confirm('Delete this note? This cannot be undone.')) return;
  try {
    await request(`/api/entries/${entry.id}`, { method: 'DELETE' });
    state.day.entries = state.day.entries.filter(item => item.id !== entry.id);
    render(); toast('Note deleted.');
  } catch (error) { toast(error.message); }
}

async function openArchives() {
  try {
    const result = await request('/api/days');
    const list = $('#archiveList');
    list.replaceChildren(...result.days.map(day => {
      const item = el('div', 'archive-item');
      const info = el('div');
      const name = el('strong'); name.textContent = day.filename;
      const detail = el('small'); detail.textContent = `${day.entries} ${day.entries === 1 ? 'entry' : 'entries'}${day.archivedAt ? ' • Archived' : ' • Current'}`;
      info.append(name, detail);
      const link = el('a'); link.href = `/api/days/${day.date}/pdf`; link.textContent = 'PDF';
      item.append(info, link); return item;
    }));
    $('#archivesDialog').showModal();
  } catch (error) { toast(error.message); }
}

function updateClock() {
  const now = new Date();
  $('#clock').textContent = new Intl.DateTimeFormat('en-US', { timeZone: 'America/Chicago', hour: 'numeric', minute: '2-digit', second: '2-digit' }).format(now);
  const parts = new Intl.DateTimeFormat('en-US', { timeZone: 'America/Chicago', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).formatToParts(now);
  const values = Object.fromEntries(parts.map(part => [part.type, part.value]));
  const shift = Number(values.hour) * 60 + Number(values.minute) >= 930 ? 2 : 1;
  const badge = $('#shiftBadge'); badge.textContent = `${ordinal(shift)} Shift`; badge.classList.toggle('shift-2', shift === 2);
}

function replaceEntry(updated) {
  state.day.entries = state.day.entries.map(entry => entry.id === updated.id ? updated : entry);
}

function renderPhotoGrid(entry) {
  const grid = el('div', 'photo-grid');
  entry.images.forEach((picture, index) => {
    const button = el('button', 'photo-thumb');
    button.type = 'button';
    button.setAttribute('aria-label', `View picture ${index + 1}: ${picture.originalName}`);
    const image = el('img');
    image.src = pictureUrl(picture);
    image.alt = picture.originalName || `Note picture ${index + 1}`;
    image.loading = 'lazy';
    const count = el('span', 'photo-count'); count.textContent = `${index + 1}/${entry.images.length}`;
    button.append(image, count);
    button.addEventListener('click', () => openPicture(picture));
    grid.append(button);
  });
  return grid;
}

function previewSelectedPictures(input, container) {
  const files = [...input.files];
  if (files.length > 4) {
    input.value = '';
    container.replaceChildren();
    toast('Choose no more than four pictures.');
    return;
  }
  container.replaceChildren(...files.map(file => {
    const item = el('div', 'pending-picture');
    const image = el('img'); image.src = URL.createObjectURL(file); image.alt = '';
    image.addEventListener('load', () => URL.revokeObjectURL(image.src), { once: true });
    const name = el('span'); name.textContent = file.name;
    item.append(image, name); return item;
  }));
}

function renderEditPictures(entry) {
  const container = $('#editPictures');
  if (!entry.images?.length) {
    const empty = el('p', 'empty'); empty.textContent = 'No pictures attached';
    container.replaceChildren(empty);
    return;
  }
  container.replaceChildren(...entry.images.map(picture => {
    const item = el('div', 'edit-picture');
    const image = el('img'); image.src = pictureUrl(picture); image.alt = picture.originalName || 'Note picture';
    image.addEventListener('click', () => openPicture(picture));
    const remove = el('button'); remove.type = 'button'; remove.textContent = '×'; remove.setAttribute('aria-label', `Remove ${picture.originalName}`);
    remove.addEventListener('click', () => removePicture(entry.id, picture.id));
    item.append(image, remove); return item;
  }));
}

async function removePicture(entryId, imageId) {
  if (!confirm('Remove this picture from the note?')) return;
  try {
    const result = await request(`/api/entries/${entryId}/images/${imageId}`, { method: 'DELETE' });
    replaceEntry(result.entry);
    render();
    renderEditPictures(result.entry);
    toast('Picture removed.');
  } catch (error) { toast(error.message); }
}

function openPicture(picture) {
  $('#fullPicture').src = pictureUrl(picture);
  $('#pictureCaption').textContent = picture.originalName || 'Note picture';
  $('#pictureDialog').showModal();
}

function pictureUrl(picture) { return `/uploads/${encodeURIComponent(picture.filename)}`; }

function formatTimestamp(iso) {
  return new Intl.DateTimeFormat('en-US', { timeZone: 'America/Chicago', hour: 'numeric', minute: '2-digit', month: 'short', day: 'numeric' }).format(new Date(iso));
}

function ordinal(number) { return number === 1 ? '1st' : '2nd'; }
function el(tag, className = '') { const node = document.createElement(tag); if (className) node.className = className; return node; }
function actionButton(text, handler, className = '') { const button = el('button', className); button.type = 'button'; button.textContent = text; button.addEventListener('click', handler); return button; }
let toastTimer;
function toast(message) { const node = $('#toast'); node.textContent = message; node.classList.add('show'); clearTimeout(toastTimer); toastTimer = setTimeout(() => node.classList.remove('show'), 2800); }

init();

