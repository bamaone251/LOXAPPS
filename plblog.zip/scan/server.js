const path = require('path');
const express = require('express');
const sqlite3 = require('sqlite3').verbose();

const PORT = process.env.PORT || 3020;
const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'data', 'plb.sqlite');

// Ensure data dir exists
const fs = require('fs');
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

const db = new sqlite3.Database(DB_PATH);
db.serialize(() => {
  db.run('PRAGMA journal_mode = WAL;');
  db.run('PRAGMA synchronous = NORMAL;');
  db.run(`
    CREATE TABLE IF NOT EXISTS entries (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      store TEXT NOT NULL,
     
      zone TEXT NOT NULL,
      ocl TEXT,
       olpn TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
  `);
});

const app = express();
app.use(express.json({ limit: '200kb' }));

// If you iframe this app from another subdomain, set CORS via env:
// CORS_ORIGIN=https://superdash.andytalbert.com
const CORS_ORIGIN = process.env.CORS_ORIGIN;
if (CORS_ORIGIN) {
  app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', CORS_ORIGIN);
    res.setHeader('Access-Control-Allow-Methods', 'GET,POST,DELETE,OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    if (req.method === 'OPTIONS') return res.sendStatus(204);
    next();
  });
}

// Serve frontend
app.use(express.static(path.join(__dirname, 'public')));

// --- simple SSE broadcast (single server instance) ---
const sseClients = new Set();
function broadcastChanged(){
  for (const res of sseClients){
    try { res.write('data: changed\n\n'); } catch {}
  }
}

app.get('/api/stream', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders?.();

  res.write('data: changed\n\n'); // initial ping

  sseClients.add(res);
  req.on('close', () => {
    sseClients.delete(res);
  });
});

// --- API ---
app.get('/api/entries', (req, res) => {
  db.all('SELECT id, store, zone, ocl, olpn, created_at FROM entries ORDER BY id ASC', [], (err, rows) => {
    if (err) return res.status(500).json({ ok:false, error: err.message });
    res.json({ ok:true, entries: rows });
  });
});

app.post('/api/entries', (req, res) => {
  const { store, olpn, zone, ocl } = req.body || {};
  if (!store || !olpn || !zone) {
    return res.status(400).json({ ok:false, error:'store, olpn, zone are required' });
  }
  const created_at = new Date().toISOString();
  db.run(
    'INSERT INTO entries (store, zone, ocl, olpn, created_at) VALUES (?,?,?,?,?)',
    [String(store).trim(), String(zone).trim(), (ocl ?? null),String(olpn).trim(), created_at],
    function(err){
      if (err) return res.status(500).json({ ok:false, error: err.message });
      const entry = { id: this.lastID, store: String(store).trim(),  zone: String(zone).trim(), olpn: String(olpn).trim(), ocl: (ocl ?? ''), created_at };
      res.json({ ok:true, entry });
      broadcastChanged();
    }
  );
});

app.delete('/api/entries/:id', (req, res) => {
  const id = req.params.id;
  db.run('DELETE FROM entries WHERE id = ?', [id], function(err){
    if (err) return res.status(500).json({ ok:false, error: err.message });
    res.json({ ok:true, deleted: this.changes });
    broadcastChanged();
  });
});

// Health check
app.get('/api/health', (req, res) => res.json({ ok:true }));

app.listen(PORT, () => {
  console.log(`✅ Lox PLB Log running on http://0.0.0.0:${PORT}`);
  console.log(`🗄️  SQLite DB: ${DB_PATH}`);
});
