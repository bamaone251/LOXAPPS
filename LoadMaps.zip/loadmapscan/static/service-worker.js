const CACHE = 'loadmap-mobile-v1';
const SHELL = ['/', '/static/css/styles.css', '/static/js/main.js'];
self.addEventListener('install', event => { event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(SHELL))); self.skipWaiting(); });
self.addEventListener('activate', event => { event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key.startsWith('loadmap-mobile-') && key !== CACHE).map(key => caches.delete(key)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);
  if (event.request.method !== 'GET' || url.origin !== location.origin || url.pathname.startsWith('/api/')) return;
  if (!SHELL.includes(url.pathname)) return;
  event.respondWith(fetch(event.request).then(response => {
    if (response.ok) { const copy=response.clone();event.waitUntil(caches.open(CACHE).then(cache => cache.put(url.pathname,copy))); }
    return response;
  }).catch(() => caches.match(url.pathname)));
});
